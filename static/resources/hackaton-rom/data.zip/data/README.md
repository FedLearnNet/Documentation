# UCI Diabetes Dataset Splitter

This small script downloads the **UCI Diabetes 130-US Hospitals dataset** and prepares it for local testing with multiple clinic datasets.

It does three things:

1. Downloads the original dataset from UCI
2. Stores the full dataset as one global CSV file
3. Splits the data into 130 smaller clinic CSV files

The clinic files are created with a deterministic round-robin split, so every clinic gets a similar number of rows.

## Output structure

After running the script, the following folder structure is created:

```text
data/
├── diabetic_data.csv
└── clinics/
    ├── clinic_001.csv
    ├── clinic_002.csv
    ├── ...
    └── clinic_130.csv
```

## Usage

Run the script with Python:

```bash
python download_and_split.py
```

Or make it executable first:

```bash
chmod +x download_and_split.py
./download_and_split.py
```

## Result

The global dataset is stored here:

```text
data/diabetic_data.csv
```

Each clinic gets its own CSV file here:

```text
data/clinics/
```

For example:

```text
data/clinics/clinic_001.csv
data/clinics/clinic_002.csv
data/clinics/clinic_003.csv
```
