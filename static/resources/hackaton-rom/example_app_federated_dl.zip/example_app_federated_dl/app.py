import os
from pathlib import Path
from typing import Any, Optional

import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from pyfedappwrap.engine.federated import FLNetMessageMetaDTO
from pyfedappwrap.learning.federated import BaseFederatedApp
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from config import (
    FederatedHospitalReadmissionConfig,
    HospitalReadmissionInputConfig,
    HospitalReadmissionOutputConfig,
)
from helper import MLP, build_prediction_df, generate_explanation_html, preprocess_diabetic


def _round_id(base: str, round_nr: int, n_rounds: int) -> str:
    if n_rounds <= 1:
        return base
    if "{round}" in base:
        return base.format(round=round_nr)
    return f"{base}-round-{round_nr}"


class FederatedHospitalReadmissionClient(
    BaseFederatedApp[
        FederatedHospitalReadmissionConfig,
        HospitalReadmissionInputConfig,
        HospitalReadmissionOutputConfig,
    ]
):
    """
    Federated Deep Learning client using FedAvg (McMahan et al. 2017).

    Each round:
      1. Client receives the global model weights from the server.
      2. Trains locally for `local_epochs` epochs on its own data.
      3. Sends updated weights back to the aggregator.
      4. Aggregator averages all clients' weights (FedAvg).

    Only model weights travel over the network — no raw patient data.
    """

    def __init__(self):
        super().__init__()
        self.model: Optional[MLP] = None
        self.scaler: Optional[StandardScaler] = None
        self.feature_columns: list[str] = []
        self.target_column: str = "hospital_readmission"

    def get_test_data(self) -> Optional[dict[str, Path]]:
        return {"data": Path("data/test_us130_wide.csv")}

    def get_test_hyperparams(self) -> dict[str, Any]:
        return {
            "communication_id": "hospital-readmission-dl",
            "output_filename": "federated_dl_predictions.csv",
            "federated_rounds": 5,
            "local_epochs": 4,
            "hidden_dim": 64,
            "n_layers": 2,
            "dropout": 0.3,
            "learning_rate": 0.001,
            "epochs": 20,
            "batch_size": 256,
            "random_state": 42,
            "test_size": 0.2,
        }

    def run_train(self, data: HospitalReadmissionInputConfig) -> HospitalReadmissionOutputConfig:
        cfg: FederatedHospitalReadmissionConfig = self.config or FederatedHospitalReadmissionConfig()
        self.target_column = cfg.target_column

        torch.manual_seed(cfg.random_state)
        np.random.seed(cfg.random_state)

        df: pd.DataFrame = data.data
        if df is None:
            raise ValueError("Training data is required.")

        X, y, feature_cols = preprocess_diabetic(df, target_col=cfg.target_column, is_training=True)
        self.feature_columns = feature_cols

        self.scaler = StandardScaler()
        X = self.scaler.fit_transform(X)

        indices = np.arange(len(y))
        train_idx, val_idx = train_test_split(
            indices, test_size=cfg.test_size, random_state=cfg.random_state, stratify=y,
        )

        n_features = X.shape[1]
        self.model = MLP(n_features, cfg.hidden_dim, cfg.n_layers, cfg.dropout)

        n_pos = int(y[train_idx].sum())
        n_neg = len(train_idx) - n_pos
        pos_weight = torch.tensor([n_neg / max(n_pos, 1)], dtype=torch.float32)
        criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

        X_t = torch.from_numpy(X[train_idx]).float()
        y_t = torch.from_numpy(y[train_idx]).float()
        X_v = torch.from_numpy(X[val_idx]).float()

        n_rounds = max(1, int(cfg.federated_rounds))
        local_epochs = max(1, int(cfg.local_epochs))
        training_history: list[dict[str, float]] = []

        for round_nr in range(1, n_rounds + 1):
            optimizer = optim.Adam(self.model.parameters(), lr=cfg.learning_rate)

            self.model.train()
            for _ in range(local_epochs):
                perm = torch.randperm(len(X_t))
                for i in range(0, len(X_t), cfg.batch_size):
                    batch_idx = perm[i:i + cfg.batch_size]
                    xb, yb = X_t[batch_idx], y_t[batch_idx]
                    optimizer.zero_grad()
                    logits = self.model(xb).squeeze(1)
                    loss = criterion(logits, yb)
                    loss.backward()
                    optimizer.step()

            communication_id = _round_id(cfg.communication_id, round_nr, n_rounds)
            response = self.communicator.aggregate(
                self._payload(self.model, len(train_idx)),
                communication_id=communication_id,
                data_type=dict,
                await_uses_newest_aggregation=False,
                meta=FLNetMessageMetaDTO(
                    communication_id=communication_id,
                    round=round_nr,
                    aggregator="fedavg",
                ),
            )

            self._load_state_dict(self.model, response.data["state_dict"], n_features)

            metrics = self._eval(X, y, train_idx, val_idx, round_nr)
            training_history.append(metrics)
            for key, val in metrics.items():
                if key != "x":
                    self.send_metric(key, val, round_nr, "round")

            self.logger.info(
                f"Round {round_nr}/{n_rounds} — "
                f"val_acc={metrics['val_accuracy']:.4f}  val_auc={metrics['val_auc']:.4f}"
            )

        return self._build_output(X, y, train_idx, val_idx, training_history, cfg)

    def run_prediction(self, data: HospitalReadmissionInputConfig) -> HospitalReadmissionOutputConfig:
        self._load("model.joblib")
        df: pd.DataFrame = data.data

        X, y_true, _ = preprocess_diabetic(
            df, target_col=self.target_column, is_training=False,
            feature_columns=self.feature_columns,
        )
        X = self.scaler.transform(X)

        ids = (df["encounter_identifier"].tolist()
               if "encounter_identifier" in df.columns else list(range(len(df))))

        self.model.eval()
        with torch.no_grad():
            X_t = torch.from_numpy(X).float()
            y_proba = torch.sigmoid(self.model(X_t).squeeze(1)).numpy()
        y_pred = (y_proba >= 0.5).astype(int)
        readmit_rate = float(y_pred.mean())
        self.send_metric("predicted_readmission_rate", readmit_rate, 0)

        pred_df = build_prediction_df(ids, y_pred, y_proba)
        metrics: dict[str, Any] = {"n_samples_prediction": len(y_pred),
                                    "n_features": X.shape[1],
                                    "predicted_readmission_rate": readmit_rate}

        if y_true is not None:
            acc = float(accuracy_score(y_true, y_pred))
            auc = float(roc_auc_score(y_true, y_proba))
            f1 = float(f1_score(y_true, y_pred, zero_division=0))
            cm = confusion_matrix(y_true, y_pred).tolist()
            rep_str = classification_report(y_true, y_pred,
                                            target_names=["Not Readmitted", "Readmitted <30d"],
                                            zero_division=0)
            fpr, tpr, _ = roc_curve(y_true, y_proba)
            metrics.update(prediction_accuracy=acc, prediction_auc=auc, prediction_f1=f1)
            report = f"Prediction — {len(y_pred)} samples, rate: {readmit_rate:.1%}\n" \
                     f"  Accuracy: {acc:.4f}  AUC: {auc:.4f}  F1: {f1:.4f}\n"
        else:
            cm, rep_str, fpr, tpr = [[0, 0], [0, 0]], "", None, None
            report = f"Prediction — {len(y_pred)} samples, rate: {readmit_rate:.1%}"

        explanation_path = Path(f"output/federated_dl_prediction_{self._safe_name()}.html")
        explanation_path.write_text(
            generate_explanation_html(metrics, cm, rep_str, val_fpr=fpr, val_tpr=tpr),
            encoding="utf-8",
        )

        return HospitalReadmissionOutputConfig(
            predictions=pred_df, explanation=explanation_path, report=report,
        )


    @staticmethod
    def _payload(model: MLP, n_samples: int) -> dict:
        state = {k: v.cpu().numpy().flatten().tolist()
                 for k, v in model.state_dict().items()}
        return {"state_dict": state, "n_samples": n_samples}

    @staticmethod
    def _load_state_dict(model: MLP, flat_state: dict[str, list], n_features: int) -> None:
        current = model.state_dict()
        new_state = {}
        for key, values in flat_state.items():
            arr = np.asarray(values, dtype=np.float32)
            new_state[key] = torch.from_numpy(arr.reshape(current[key].shape))
        model.load_state_dict(new_state)

    def _eval(self, X, y, train_idx, val_idx, round_nr) -> dict[str, float]:
        self.model.eval()
        with torch.no_grad():
            train_proba = torch.sigmoid(
                self.model(torch.from_numpy(X[train_idx]).float()).squeeze(1)
            ).numpy()
            val_proba = torch.sigmoid(
                self.model(torch.from_numpy(X[val_idx]).float()).squeeze(1)
            ).numpy()
        y_train, y_val = y[train_idx], y[val_idx]
        return {
            "x": float(round_nr),
            "train_accuracy": float(accuracy_score(y_train, (train_proba >= 0.5).astype(int))),
            "val_accuracy": float(accuracy_score(y_val, (val_proba >= 0.5).astype(int))),
            "train_auc": float(roc_auc_score(y_train, train_proba)),
            "val_auc": float(roc_auc_score(y_val, val_proba)),
        }

    def _build_output(self, X, y, train_idx, val_idx, history, cfg) -> HospitalReadmissionOutputConfig:
        self.model.eval()
        with torch.no_grad():
            val_proba = torch.sigmoid(
                self.model(torch.from_numpy(X[val_idx]).float()).squeeze(1)
            ).numpy()
            train_proba = torch.sigmoid(
                self.model(torch.from_numpy(X[train_idx]).float()).squeeze(1)
            ).numpy()

        y_train, y_val = y[train_idx], y[val_idx]
        val_pred = (val_proba >= 0.5).astype(int)
        val_fpr, val_tpr, _ = roc_curve(y_val, val_proba)

        metrics = {
            "n_samples_train": len(y_train),
            "n_samples_val": len(y_val),
            "n_features": X.shape[1],
            "federated_rounds": len(history),
            "train_accuracy": float(accuracy_score(y_train, (train_proba >= 0.5).astype(int))),
            "val_accuracy": float(accuracy_score(y_val, val_pred)),
            "train_auc": float(roc_auc_score(y_train, train_proba)),
            "val_auc": float(roc_auc_score(y_val, val_proba)),
            "val_precision": float(precision_score(y_val, val_pred, zero_division=0)),
            "val_recall": float(recall_score(y_val, val_pred, zero_division=0)),
            "val_f1": float(f1_score(y_val, val_pred, zero_division=0)),
        }

        for key in ("val_accuracy", "val_auc", "val_precision", "val_recall", "val_f1",
                    "train_accuracy", "train_auc"):
            self.send_metric(f"final_{key}", metrics[key], len(history), "round")

        val_cm = confusion_matrix(y_val, val_pred).tolist()
        val_report = classification_report(y_val, val_pred,
                                           target_names=["Not Readmitted", "Readmitted <30d"],
                                           zero_division=0)

        explanation_path = Path(f"output/federated_dl_explanation_{self._safe_name()}.html")
        explanation_path.write_text(
            generate_explanation_html(metrics, val_cm, val_report,
                                      training_history=history,
                                      val_fpr=val_fpr, val_tpr=val_tpr),
            encoding="utf-8",
        )

        pred_df = build_prediction_df(val_idx.tolist(), val_pred, val_proba)
        report = (
            f"Federated MLP Summary\n{'=' * 40}\n"
            f"Samples: {metrics['n_samples_train']} train / {metrics['n_samples_val']} val\n"
            f"Features: {metrics['n_features']}, Rounds: {metrics['federated_rounds']}\n"
            f"Val — Acc: {metrics['val_accuracy']:.4f}, AUC: {metrics['val_auc']:.4f}, "
            f"F1: {metrics['val_f1']:.4f}\n"
        )
        if self.logger:
            self.logger.info(report)

        self._save()
        self.save_local_csv(pred_df, cfg.output_filename)

        return HospitalReadmissionOutputConfig(
            predictions=pred_df, explanation=explanation_path, report=report,
        )

    def _safe_name(self) -> str:
        text = str(self.app_id or "client")
        return "".join(c if c.isalnum() or c in "-_" else "_" for c in text)

    def _save(self) -> str:
        model_dir = os.environ.get("MODEL_DIR", "./model/")
        path = Path(model_dir) / "model.joblib"
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({
            "model_state": self.model.state_dict(),
            "model_arch": {"n_features": self.model.net[0].in_features,
                           "hidden_dim": self.model.hidden_dim,
                           "n_layers": self.model.n_layers,
                           "dropout": self.model.dropout_rate},
            "scaler": self.scaler,
            "feature_columns": self.feature_columns,
            "target_column": self.target_column,
        }, path)
        return "model.joblib"

    def _load(self, path: str) -> None:
        if self.model is not None:
            return
        model_dir = os.environ.get("MODEL_DIR", "./model/")
        artifact = joblib.load(Path(model_dir) / path)
        arch = artifact["model_arch"]
        self.model = MLP(arch["n_features"], arch["hidden_dim"],
                         arch["n_layers"], arch["dropout"])
        self.model.load_state_dict(artifact["model_state"])
        self.model.eval()
        self.scaler = artifact["scaler"]
        self.feature_columns = artifact["feature_columns"]
        self.target_column = artifact["target_column"]
