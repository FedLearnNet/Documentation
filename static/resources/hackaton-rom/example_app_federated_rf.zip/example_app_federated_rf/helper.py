"""
Preprocessing, output builders, and HTML report for the
Federated Random Forest Hospital Readmission app (test_us130_wide schema).
"""

import json

import numpy as np
import pandas as pd


AGE_MAP = {
    "[0-10)": 5, "[10-20)": 15, "[20-30)": 25, "[30-40)": 35, "[40-50)": 45,
    "[50-60)": 55, "[60-70)": 65, "[70-80)": 75, "[80-90)": 85, "[90-100)": 95,
}

MEDICATION_COLS = [
    "metformin_pioglitazone", "metformin_rosiglitazone", "glimepiride_pioglitazone",
    "glipizide_metformin", "glyburide_metformin", "insulin", "citoglipton",
    "examide", "tolazamide", "troglitazone", "miglitol", "acarbose",
    "rosiglitazone", "pioglitazone", "tolbutamide", "glyburide", "glipizide",
    "acetohexamide", "glimepiride", "chlorpropamide", "nateglinide",
    "repaglinide", "metformin",
]

DROP_COLS = [
    "patient_id", "patient_number", "age", "age_age_years",
    "height", "body_height_observable_entity",
    "diastolic_blood_pressure_observable_entity",
    "systolic_blood_pressure_observable_entity_diastolic_blood_pressure_observable_entity",
    "diabetes", "diabetes_mellitus_type_2_disorder",
    "body_weight", "weight", "body_weight_observable_entity",
    "payer_code", "gender_observable_entity", "sex_assigned_at_birth",
]

CAST_TO_STR_COLS = ["admission_source", "discharge_disposition", "admission_type"]
DIAG_COLS = ["primary_diagnosis", "secondary_diagnosis", "tertiary_diagnosis"]


def _map_diagnosis(code) -> str:
    try:
        code = str(code).strip()
        if not code or code in ("nan", "?"):
            return "Other"
        if code.startswith("V") or code.startswith("E"):
            return "Other"
        num = float(code.split(".")[0])
        if 390 <= num <= 459 or num == 785: return "Circulatory"
        if 460 <= num <= 519 or num == 786: return "Respiratory"
        if 520 <= num <= 579 or num == 787: return "Digestive"
        if 250 <= num < 251: return "Diabetes"
        if 800 <= num <= 999: return "Injury"
        if 710 <= num <= 739: return "Musculoskeletal"
        if 580 <= num <= 629 or num == 788: return "Genitourinary"
        if 140 <= num <= 239: return "Neoplasms"
        return "Other"
    except (ValueError, AttributeError):
        return "Other"


def preprocess_diabetic(
    df: pd.DataFrame,
    target_col: str = "hospital_readmission",
    is_training: bool = True,
    feature_columns: list[str] | None = None,
) -> tuple[np.ndarray, np.ndarray | None, list[str]]:
    df = df.copy()
    df.replace("?", np.nan, inplace=True)
    df.drop(columns=[c for c in DROP_COLS if c in df.columns], inplace=True)

    if "age_age_group_bracket" in df.columns:
        df["age_numeric"] = df["age_age_group_bracket"].map(AGE_MAP)
        df.drop(columns=["age_age_group_bracket"], inplace=True)

    for diag in DIAG_COLS:
        if diag in df.columns:
            df[f"{diag}_cat"] = df[diag].apply(_map_diagnosis)
            df.drop(columns=[diag], inplace=True)

    for med in MEDICATION_COLS:
        if med in df.columns:
            df[med] = (df[med].fillna("No") != "No").astype(np.int8)

    if "diabetes_medication_prescribed" in df.columns:
        df["diabetes_medication_prescribed"] = (
            df["diabetes_medication_prescribed"].fillna("No") == "Yes"
        ).astype(np.int8)

    if "medication_change" in df.columns:
        df["medication_change"] = (df["medication_change"].fillna("No") == "Ch").astype(np.int8)

    for col in CAST_TO_STR_COLS:
        if col in df.columns:
            df[col] = df[col].astype(str)

    for col in ["maximum_glucose_serum", "hb_a1c"]:
        if col in df.columns:
            df[col] = df[col].fillna("None")

    y = None
    if target_col in df.columns:
        raw = df.pop(target_col)
        y = (raw == "<30").astype(int).values

    df.dropna(axis=1, how="all", inplace=True)

    cat_cols = [c for c in df.columns if df[c].dtype == object]
    if cat_cols:
        df = pd.get_dummies(df, columns=cat_cols, dummy_na=False)

    for col in df.select_dtypes(include=[np.number]).columns:
        if df[col].isnull().any():
            df[col] = df[col].fillna(df[col].median())

    if not is_training and feature_columns is not None:
        df = df.reindex(columns=feature_columns, fill_value=0)

    return df.values.astype(np.float64), y, list(df.columns)


def build_prediction_df(ids, y_pred, y_proba) -> pd.DataFrame:
    return pd.DataFrame({
        "id": ids,
        "readmitted_30d_predicted": y_pred.astype(int),
        "probability_readmitted": np.round(y_proba, 4),
        "probability_not_readmitted": np.round(1.0 - y_proba, 4),
    })


def feature_importance_table(feature_names: list[str], importances: np.ndarray) -> pd.DataFrame:
    return (
        pd.DataFrame({"feature": feature_names, "importance": importances.astype(float)})
        .sort_values("importance", ascending=False)
        .reset_index(drop=True)
    )


def generate_explanation_html(
    importance_df: pd.DataFrame,
    metrics: dict,
    confusion_mat: list[list[int]],
    classification_rep: str,
    training_history: list[dict] | None = None,
    top_k: int = 20,
    val_fpr: np.ndarray | None = None,
    val_tpr: np.ndarray | None = None,
) -> str:
    top_features = importance_df.head(top_k)
    metric_rows = "\n".join(
        f"  <tr><td>{k.replace('_',' ').title()}</td><td><b>{v:.4f}</b></td></tr>"
        if isinstance(v, float)
        else f"  <tr><td>{k.replace('_',' ').title()}</td><td><b>{v}</b></td></tr>"
        for k, v in metrics.items()
    )
    tn, fp, fn, tp = (confusion_mat[0][0], confusion_mat[0][1],
                      confusion_mat[1][0], confusion_mat[1][1])
    bar_features_json = json.dumps(top_features["feature"].tolist()[::-1])
    bar_values_json = json.dumps([round(float(v), 4) for v in top_features["importance"].tolist()[::-1]])

    history_html = ""
    if training_history:
        x_vals = json.dumps([h["x"] for h in training_history])
        history_html = f"""
<h2>Training History (per Round)</h2>
<div id="history_chart" style="width:100%;height:380px;"></div>
<script>
(function(){{
  var c = echarts.init(document.getElementById('history_chart'));
  c.setOption({{
    title:{{text:'Metrics over Federated Rounds',left:'center'}},
    tooltip:{{trigger:'axis'}}, legend:{{bottom:0}},
    xAxis:{{type:'category',data:{x_vals},name:'Round',nameLocation:'center',nameGap:28}},
    yAxis:{{type:'value',min:0,max:1}},
    series:[
      {{name:'Train Acc',type:'line',data:{json.dumps([round(h["train_accuracy"],4) for h in training_history])},smooth:true}},
      {{name:'Val Acc',type:'line',data:{json.dumps([round(h["val_accuracy"],4) for h in training_history])},smooth:true,lineStyle:{{type:'dashed'}}}},
      {{name:'Train AUC',type:'line',data:{json.dumps([round(h["train_auc"],4) for h in training_history])},smooth:true}},
      {{name:'Val AUC',type:'line',data:{json.dumps([round(h["val_auc"],4) for h in training_history])},smooth:true,lineStyle:{{type:'dashed'}}}}
    ]
  }});
}})();
</script>"""

    roc_html = ""
    if val_fpr is not None and val_tpr is not None:
        step = max(1, len(val_fpr) // 300)
        roc_data = json.dumps([[round(float(x), 4), round(float(y), 4)]
                               for x, y in zip(val_fpr[::step], val_tpr[::step])])
        roc_auc = metrics.get("val_auc", 0.0)
        roc_html = f"""
<h2>ROC Curve (Validation Set)</h2>
<div id="roc_chart" style="width:100%;height:400px;"></div>
<script>
(function(){{
  var c = echarts.init(document.getElementById('roc_chart'));
  c.setOption({{
    title:{{text:'ROC Curve — AUC = {roc_auc:.4f}',left:'center'}},
    tooltip:{{trigger:'axis'}},
    xAxis:{{type:'value',name:'False Positive Rate',min:0,max:1,nameLocation:'center',nameGap:28}},
    yAxis:{{type:'value',name:'True Positive Rate',min:0,max:1,nameLocation:'center',nameGap:36}},
    series:[
      {{name:'ROC',type:'line',data:{roc_data},showSymbol:false,lineStyle:{{color:'#27ae60',width:2}}}},
      {{name:'Random',type:'line',data:[[0,0],[1,1]],showSymbol:false,lineStyle:{{color:'#95a5a6',type:'dashed'}}}}
    ]
  }});
}})();
</script>"""

    return f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8">
<title>Federated RF — Hospital Readmission Report</title>
<script src="https://cdn.jsdelivr.net/npm/echarts@5/dist/echarts.min.js"></script>
<style>
  body{{font-family:Arial,sans-serif;max-width:1100px;margin:0 auto;padding:24px;color:#2c3e50;line-height:1.5}}
  h1{{border-bottom:2px solid #2c3e50;padding-bottom:8px}} h2{{color:#27ae60;margin-top:32px}}
  table{{border-collapse:collapse;width:100%;margin:10px 0}}
  th{{background:#2c3e50;color:#fff;padding:8px 14px;text-align:left}}
  td{{padding:6px 14px;border-bottom:1px solid #ecf0f1}} tr:nth-child(even) td{{background:#f8f9fa}}
  .cm td{{text-align:center;padding:12px 24px;font-size:1.1em}}
  .good{{background:#d5f5e3}} .bad{{background:#fadbd8}}
  pre{{background:#f8f9fa;padding:16px;border-left:4px solid #27ae60;overflow-x:auto;font-size:13px}}
</style></head>
<body>
<h1>Hospital Readmission — Federated Random Forest Report</h1>
<p>Each clinic trained a local Random Forest; feature importances were shared (not raw data).</p>
<h2>Metrics</h2>
<table><tr><th>Metric</th><th>Value</th></tr>{metric_rows}</table>
<h2>Confusion Matrix</h2>
<table class="cm">
  <tr><th></th><th>Predicted: Not Readmitted</th><th>Predicted: Readmitted (&lt;30d)</th></tr>
  <tr><td><b>Actual: Not Readmitted</b></td><td class="good">TN={tn}</td><td class="bad">FP={fp}</td></tr>
  <tr><td><b>Actual: Readmitted</b></td><td class="bad">FN={fn}</td><td class="good">TP={tp}</td></tr>
</table>
<h2>Classification Report</h2><pre>{classification_rep}</pre>
{history_html}{roc_html}
<h2>Feature Importance — Top {top_k}</h2>
<div id="importance_chart" style="width:100%;height:620px;"></div>
<script>
(function(){{
  var c = echarts.init(document.getElementById('importance_chart'));
  c.setOption({{
    title:{{text:'Feature Importance (Federated Random Forest)',left:'center'}},
    tooltip:{{trigger:'axis',axisPointer:{{type:'shadow'}}}},
    grid:{{left:'38%',right:'12%',containLabel:false}},
    xAxis:{{type:'value',name:'Importance',nameLocation:'center',nameGap:26}},
    yAxis:{{type:'category',data:{bar_features_json},axisLabel:{{fontSize:11}}}},
    series:[{{name:'Importance',type:'bar',data:{bar_values_json},
      itemStyle:{{color:'#27ae60'}},
      label:{{show:true,position:'right',formatter:function(p){{return p.value.toFixed(4)}}}}
    }}]
  }});
}})();
</script>
</body></html>"""
