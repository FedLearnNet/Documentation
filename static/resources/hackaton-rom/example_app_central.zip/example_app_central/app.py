import os
from pathlib import Path
from typing import Optional

import joblib
import pandas as pd
from pyfedappwrap.learning.base_app import BaseApp
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from config import (
    HospitalReadmissionConfig,
    HospitalReadmissionInputConfig,
    HospitalReadmissionOutputConfig,
)
from helper import (
    build_prediction_df,
    coef_table,
    generate_explanation_html,
    preprocess_diabetic,
)

# Number of metric checkpoints during training (simulated epochs via warm_start)
N_STEPS = 10


class HospitalReadmissionApp(
    BaseApp[
        HospitalReadmissionConfig,
        HospitalReadmissionInputConfig,
        HospitalReadmissionOutputConfig,
    ]
):
    def __init__(self):
        super().__init__()
        self.model: Optional[LogisticRegression] = None
        self.scaler: Optional[StandardScaler] = None
        self.feature_columns: list[str] = []
        self.target_column: str = "hospital_readmission"

    def get_test_data(self) -> Optional[dict[str, Path]]:
        return {"data": Path("data/test_us130_wide.csv")}

    # ------------------------------------------------------------------
    # Training
    # ------------------------------------------------------------------

    def run_train(
            self, data: HospitalReadmissionInputConfig
    ) -> HospitalReadmissionOutputConfig:
        self.logger.info(f"Running train")
        cfg: HospitalReadmissionConfig = self.config
        self.target_column = cfg.target_column

        df: pd.DataFrame = data.data
        self.logger.info(f"Dataset loaded: {df.shape[0]} rows × {df.shape[1]} columns")

        X, y, feature_cols = preprocess_diabetic(
            df, target_col=cfg.target_column, is_training=True
        )
        self.feature_columns = feature_cols

        n_pos = int(y.sum())
        n_neg = int(len(y) - n_pos)
        pos_pct = n_pos / len(y) * 100
        self.logger.info(
            f"Preprocessed: {X.shape[0]} samples, {X.shape[1]} features | "
            f"NOT readmitted: {n_neg} ({100 - pos_pct:.1f}%) | "
            f"Readmitted <30d: {n_pos} ({pos_pct:.1f}%)"
        )

        X_train, X_val, y_train, y_val = train_test_split(
            X, y,
            test_size=cfg.test_size,
            random_state=cfg.random_state,
            stratify=y,
        )
        self.logger.info(f"Train/val split: {X_train.shape[0]} / {X_val.shape[0]}")

        if cfg.standardize:
            self.scaler = StandardScaler()
            X_train = self.scaler.fit_transform(X_train)
            X_val = self.scaler.transform(X_val)
            self.logger.info("Features standardized (StandardScaler fitted on train set)")
        else:
            self.scaler = None

        class_weight = None if cfg.class_weight == "none" else cfg.class_weight
        iters_per_step = max(1, cfg.max_iter // N_STEPS)
        self.logger.info(
            f"Fitting LogisticRegression(C={cfg.C}, solver={cfg.solver}, "
            f"max_iter={cfg.max_iter}, class_weight={class_weight}) "
            f"in {N_STEPS} steps of {iters_per_step} iterations each"
        )

        # warm_start=True lets each fit() call continue from the previous state,
        # giving us genuine per-step training curves.
        self.model = LogisticRegression(
            C=cfg.C,
            solver=cfg.solver,
            max_iter=iters_per_step,
            class_weight=class_weight,
            random_state=cfg.random_state,
            warm_start=True,
        )

        training_history: list[dict] = []
        total_iters_actual = 0

        for step in range(N_STEPS):
            self.model.fit(X_train, y_train)
            total_iters_actual += int(self.model.n_iter_[0])

            step_train_pred = self.model.predict(X_train)
            step_train_proba = self.model.predict_proba(X_train)[:, 1]
            step_val_pred = self.model.predict(X_val)
            step_val_proba = self.model.predict_proba(X_val)[:, 1]

            step_train_acc = float(accuracy_score(y_train, step_train_pred))
            step_val_acc = float(accuracy_score(y_val, step_val_pred))
            step_train_auc = float(roc_auc_score(y_train, step_train_proba))
            step_val_auc = float(roc_auc_score(y_val, step_val_proba))

            # x = iteration budget consumed so far — gives a meaningful x-axis even
            # when the solver converges early and subsequent steps add 0 real iters
            x_budget = (step + 1) * iters_per_step
            self.send_metric("train_accuracy", step_train_acc, x_budget)
            self.send_metric("val_accuracy", step_val_acc, x_budget)
            self.send_metric("train_auc", step_train_auc, x_budget)
            self.send_metric("val_auc", step_val_auc, x_budget)

            training_history.append({
                "x": x_budget,
                "train_accuracy": step_train_acc,
                "val_accuracy": step_val_acc,
                "train_auc": step_train_auc,
                "val_auc": step_val_auc,
            })

            self.logger.info(
                f"Step {step + 1}/{N_STEPS} (budget={x_budget}, actual_iter={total_iters_actual}) — "
                f"val_acc={step_val_acc:.4f}  val_auc={step_val_auc:.4f}"
            )

        # --- Final evaluation ---
        val_pred = self.model.predict(X_val)
        val_proba = self.model.predict_proba(X_val)[:, 1]
        val_fpr, val_tpr, _ = roc_curve(y_val, val_proba)

        train_pred = self.model.predict(X_train)
        train_proba = self.model.predict_proba(X_train)[:, 1]

        val_accuracy = float(accuracy_score(y_val, val_pred))
        val_auc = float(roc_auc_score(y_val, val_proba))
        val_precision = float(precision_score(y_val, val_pred, zero_division=0))
        val_recall = float(recall_score(y_val, val_pred, zero_division=0))
        val_f1 = float(f1_score(y_val, val_pred, zero_division=0))
        train_accuracy = float(accuracy_score(y_train, train_pred))
        train_auc = float(roc_auc_score(y_train, train_proba))

        # Send final summary metrics (x = full iteration budget)
        x_final = N_STEPS * iters_per_step
        self.send_metric("final_train_accuracy", train_accuracy, x_final)
        self.send_metric("final_val_accuracy", val_accuracy, x_final)
        self.send_metric("final_val_auc", val_auc, x_final)
        self.send_metric("final_val_precision", val_precision, x_final)
        self.send_metric("final_val_recall", val_recall, x_final)
        self.send_metric("final_val_f1", val_f1, x_final)

        metrics = {
            "n_samples_train": int(len(y_train)),
            "n_samples_val": int(len(y_val)),
            "n_features": int(X_train.shape[1]),
            "total_iterations": total_iters_actual,
            "train_accuracy": train_accuracy,
            "val_accuracy": val_accuracy,
            "train_auc": train_auc,
            "val_auc": val_auc,
            "val_precision": val_precision,
            "val_recall": val_recall,
            "val_f1": val_f1,
        }

        self.logger.info(
            f"Final — val_acc={val_accuracy:.4f}  val_auc={val_auc:.4f}  "
            f"precision={val_precision:.4f}  recall={val_recall:.4f}  f1={val_f1:.4f}"
        )

        val_cm = confusion_matrix(y_val, val_pred).tolist()
        val_report = classification_report(
            y_val, val_pred,
            target_names=["Not Readmitted", "Readmitted <30d"],
        )
        self.logger.info(f"Classification Report (validation):\n{val_report}")

        # --- Build outputs ---
        coef_df = coef_table(self.feature_columns, self.model.coef_, self.model.intercept_)

        explanation_path = Path("output/explanation.html")
        explanation_path.write_text(
            generate_explanation_html(
                coef_df, metrics, val_cm, val_report,
                training_history=training_history,
                top_k=20,
                val_fpr=val_fpr,
                val_tpr=val_tpr,
            ),
            encoding="utf-8",
        )

        val_ids = list(range(len(y_val)))
        pred_df = build_prediction_df(val_ids, val_pred, val_proba)

        report = (
            "Hospital Readmission Prediction — Training Summary\n"
            f"{'=' * 52}\n"
            f"Samples       : {metrics['n_samples_train']} train  /  {metrics['n_samples_val']} val\n"
            f"Features      : {metrics['n_features']}\n"
            f"Total iters   : {metrics['total_iterations']}  ({N_STEPS} steps)\n"
            "\nValidation Performance:\n"
            f"  Accuracy    : {val_accuracy:.4f}\n"
            f"  AUC-ROC     : {val_auc:.4f}\n"
            f"  Precision   : {val_precision:.4f}\n"
            f"  Recall      : {val_recall:.4f}\n"
            f"  F1-Score    : {val_f1:.4f}\n"
            "\nTrain Performance:\n"
            f"  Accuracy    : {train_accuracy:.4f}\n"
            f"  AUC-ROC     : {train_auc:.4f}\n"
        )
        self.logger.info(report)

        self._save()

        return HospitalReadmissionOutputConfig(
            predictions=pred_df,
            coefficients=coef_df,
            explanation=explanation_path,
            report=report,
        )

    # ------------------------------------------------------------------
    # Prediction
    # ------------------------------------------------------------------

    def run_prediction(
            self, data: HospitalReadmissionInputConfig
    ) -> HospitalReadmissionOutputConfig:
        self._load("model.joblib")
        self.logger.info("Running prediction")
        df: pd.DataFrame = data.data
        self.logger.info(f"Data loaded: {df.shape[0]} rows × {df.shape[1]} columns")

        X, y_true, _ = preprocess_diabetic(
            df,
            target_col=self.target_column,
            is_training=False,
            feature_columns=self.feature_columns,
        )

        if self.scaler is not None:
            X = self.scaler.transform(X)

        ids = (
            df["encounter_identifier"].tolist()
            if "encounter_identifier" in df.columns
            else list(range(len(df)))
        )

        y_pred = self.model.predict(X)
        y_proba = self.model.predict_proba(X)[:, 1]
        readmit_rate = float(y_pred.mean())

        self.send_metric("predicted_readmission_rate", readmit_rate, 0)

        pred_df = build_prediction_df(ids, y_pred, y_proba)
        coef_df = coef_table(self.feature_columns, self.model.coef_, self.model.intercept_)

        metrics = {
            "n_samples_prediction": int(len(y_pred)),
            "n_features": int(X.shape[1]),
            "predicted_readmission_rate": readmit_rate,
        }

        if y_true is not None:
            pred_accuracy = float(accuracy_score(y_true, y_pred))
            pred_auc = float(roc_auc_score(y_true, y_proba))
            pred_precision = float(precision_score(y_true, y_pred, zero_division=0))
            pred_recall = float(recall_score(y_true, y_pred, zero_division=0))
            pred_f1 = float(f1_score(y_true, y_pred, zero_division=0))
            pred_cm = confusion_matrix(y_true, y_pred).tolist()
            pred_report = classification_report(
                y_true,
                y_pred,
                target_names=["Not Readmitted", "Readmitted <30d"],
                zero_division=0,
            )
            pred_fpr, pred_tpr, _ = roc_curve(y_true, y_proba)

            metrics.update({
                "prediction_accuracy": pred_accuracy,
                "prediction_auc": pred_auc,
                "prediction_precision": pred_precision,
                "prediction_recall": pred_recall,
                "prediction_f1": pred_f1,
            })

            report = (
                f"Prediction complete — {len(y_pred)} samples\n"
                f"Predicted readmission rate (<30d): {readmit_rate:.3f} ({readmit_rate * 100:.1f}%)\n"
                "\nPrediction Performance:\n"
                f"  Accuracy    : {pred_accuracy:.4f}\n"
                f"  AUC-ROC     : {pred_auc:.4f}\n"
                f"  Precision   : {pred_precision:.4f}\n"
                f"  Recall      : {pred_recall:.4f}\n"
                f"  F1-Score    : {pred_f1:.4f}\n"
            )
        else:
            pred_cm = [[0, 0], [0, 0]]
            pred_report = "No target column available in prediction data. Only predicted labels and probabilities were generated."
            pred_fpr = None
            pred_tpr = None

            report = (
                f"Prediction complete — {len(y_pred)} samples\n"
                f"Predicted readmission rate (<30d): {readmit_rate:.3f} ({readmit_rate * 100:.1f}%)"
            )

        explanation_path = Path("output/prediction_explanation.html")
        explanation_path.write_text(
            generate_explanation_html(
                coef_df,
                metrics,
                pred_cm,
                pred_report,
                training_history=[],
                top_k=20,
                val_fpr=pred_fpr,
                val_tpr=pred_tpr,
            ),
            encoding="utf-8",
        )

        self.logger.info(report)

        return HospitalReadmissionOutputConfig(
            predictions=pred_df,
            coefficients=coef_df,
            explanation=explanation_path,
            report=report,
        )

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _save(self) -> str:
        model_dir = os.environ.get("MODEL_DIR", "./model/")
        path = Path(model_dir) / "model.joblib"
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(
            {
                "model": self.model,
                "scaler": self.scaler,
                "feature_columns": self.feature_columns,
                "target_column": self.target_column,
            },
            path,
        )
        self.logger.info(f"Artifact saved → {path}")
        return "model.joblib"  # without filder

    def _load(self, path: str) -> None:
        if self.model is not None:
            return
        model_dir = os.environ.get("MODEL_DIR", "./model/")
        artifact_path = Path(model_dir) / path
        artifact = joblib.load(artifact_path)
        self.model = artifact["model"]
        self.scaler = artifact["scaler"]
        self.feature_columns = artifact["feature_columns"]
        self.target_column = artifact["target_column"]
        self.logger.info(f"Artifact loaded ← {path}")
