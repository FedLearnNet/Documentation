from __future__ import annotations

from typing import Any, Optional

import numpy as np

from pyfedappwrap.engine.federated import AppAggregator, FLNetMessageMetaDTO


class MajorityVoteAggregator(AppAggregator):
    """
    Aggregator for federated Random Forest.

    Each client sends per-sample predicted probabilities. The aggregator
    averages them across all clients (ensemble of local forests) and returns
    the averaged probabilities along with metadata.
    """

    def aggregate(
        self,
        data: list[Any],
        n_clients: int,
        meta: Optional[FLNetMessageMetaDTO] = None,
    ) -> Any:
        if not data:
            raise ValueError("Cannot aggregate an empty payload list.")

        if all(isinstance(item, dict) and "feature_importances" in item for item in data):
            return self._aggregate_importances(data, n_clients, meta)

        return np.mean(np.stack(data), axis=0)

    @staticmethod
    def _aggregate_importances(
        payloads: list[dict[str, Any]],
        n_clients: int,
        meta: Optional[FLNetMessageMetaDTO] = None,
    ) -> dict[str, Any]:
        feature_columns: list[str] = []
        seen: set[str] = set()
        total_samples = 0
        total_trees = 0
        weighted_importances: dict[str, float] = {}

        for payload in payloads:
            weight = int(payload.get("n_samples", 1))
            total_samples += weight
            total_trees += int(payload.get("n_trees", 0))

            for feature, importance in payload.get("feature_importances", {}).items():
                if feature not in seen:
                    seen.add(feature)
                    feature_columns.append(feature)
                weighted_importances[feature] = (
                    weighted_importances.get(feature, 0.0) + float(importance) * weight
                )

        divisor = total_samples or n_clients
        return {
            "feature_columns": feature_columns,
            "feature_importances": [
                weighted_importances.get(f, 0.0) / divisor for f in feature_columns
            ],
            "n_clients": n_clients,
            "n_samples": total_samples,
            "n_trees_total": total_trees,
            "round": meta.round if meta else None,
            "communication_id": meta.communication_id if meta else None,
        }
