from pathlib import Path
from typing import Any

from pydantic.dataclasses import dataclass
from pyfedappwrap.learning.run_runfig import AppConfig, AppInputConfig, AppOutputConfig


@dataclass
class HospitalReadmissionConfig(AppConfig):
    target_column: str = "hospital_readmission"
    alpha: float = 0.0001
    class_weight: str = "balanced"
    random_state: int = 42
    test_size: float = 0.2


@dataclass
class HospitalReadmissionInputConfig(AppInputConfig):
    data: Any = None


@dataclass
class HospitalReadmissionOutputConfig(AppOutputConfig):
    predictions: Any | None = None
    explanation: Path | None = None
    report: str | None = None


@dataclass
class FederatedHospitalReadmissionConfig(HospitalReadmissionConfig):
    communication_id: str = "hospital-readmission-svm"
    output_filename: str = "federated_svm_readmission_predictions.csv"
    federated_rounds: int = 10
    local_epochs: int = 5
