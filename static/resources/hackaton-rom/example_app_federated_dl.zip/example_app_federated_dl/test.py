from pyfedappwrap.engine.runtime import FedDBEngine

from aggregator import FedAvgAggregator
from app import FederatedHospitalReadmissionClient

engine = FedDBEngine(test_mode=True)

engine.register_aggregator(FedAvgAggregator(), "fedavg")
engine.register_federated(FederatedHospitalReadmissionClient())

if __name__ == '__main__':
    print("Starting test engine...")
    engine.start()
    engine.wait_until_stop()
