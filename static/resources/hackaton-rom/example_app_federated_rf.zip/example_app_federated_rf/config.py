from pathlib import Path
from typing import Any

from pydantic.dataclasses import dataclass
from pyfedappwrap.learning.run_runfig import AppConfig, AppInputConfig, AppOutputConfig


@dataclass
class HospitalReadmissionConfig(AppConfig):
    target_column: str = "hospital_readmission"
    n_estimators: int = 100
    max_depth: int = 10
    min_samples_split: int = 5
    min_samples_leaf: int = 2
    class_weight: str = "balanced"
    random_state: int = 42
    test_size: float = 0.2


@dataclass
class HospitalReadmissionInputConfig(AppInputConfig):
    data: Any = None


@dataclass
class HospitalReadmissionOutputConfig(AppOutputConfig):
    predictions: Any | None = None
    feature_importances: Any | None = None
    explanation: Path | None = None
    report: str | None = None


@dataclass
class FederatedHospitalReadmissionConfig(HospitalReadmissionConfig):
    communication_id: str = "hospital-readmission-rf"
    output_filename: str = "federated_rf_readmission_predictions.csv"
    federated_rounds: int = 5
    local_n_estimators: int = 20
