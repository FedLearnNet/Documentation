#!/bin/sh
set -euo pipefail

CLINIC_COUNT="${1:-3}"
START_PORT="${2:-4601}"
IMAGE_TAG="${IMAGE_TAG:-feddb-dind}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CLINIC_DIND_DIR="$SCRIPT_DIR/clinic-dind"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
DATASET_DIR="$SCRIPT_DIR/example-data/us-130/clinics"
CONNECTOR_HOST_PATH="$CLINIC_DIND_DIR/us-130-clinics.json"

if ! command -v docker >/dev/null 2>&1; then
  echo "docker is required." >&2
  exit 1
fi

case "$CLINIC_COUNT" in
  ''|*[!0-9]*)
    echo "Clinic count must be a positive integer." >&2
    exit 1
    ;;
esac

case "$START_PORT" in
  ''|*[!0-9]*)
    echo "Start port must be a positive integer." >&2
    exit 1
    ;;
esac

if [ "$CLINIC_COUNT" -lt 1 ]; then
  echo "Clinic count must be at least 1." >&2
  exit 1
fi

if [ "$CLINIC_COUNT" -gt 130 ]; then
  echo "Only 130 US-130 clinic CSVs are available." >&2
  exit 1
fi

if ! docker image inspect "$IMAGE_TAG" >/dev/null 2>&1; then
  echo "▷ Image $IMAGE_TAG not found. Building it first..."
  (
    cd "$CLINIC_DIND_DIR"
    ./build-local-dind.sh
  )
fi

index=1
while [ "$index" -le "$CLINIC_COUNT" ]; do
  clinic_id="$(printf '%03d' "$index")"
  dataset_name="clinic_${clinic_id}.csv"
  dataset_host_path="$DATASET_DIR/$dataset_name"
  host_port=$((START_PORT + index - 1))
  container_name="clinic-dind-us130-${clinic_id}"
  compose_project_name="fl-net-clinic${index}"
  docker_volume_name="${container_name}-docker"

  if [ ! -f "$dataset_host_path" ]; then
    echo "Missing dataset: $dataset_host_path" >&2
    exit 1
  fi

  if [ ! -f "$CONNECTOR_HOST_PATH" ]; then
    echo "Missing connector config: $CONNECTOR_HOST_PATH" >&2
    exit 1
  fi

  if docker container inspect "$container_name" >/dev/null 2>&1; then
    echo "▷ Removing existing container $container_name"
    docker rm -f "$container_name" >/dev/null
  fi

  echo "▷ Starting $container_name on http://localhost:${host_port}"
  # Keep the Docker daemon inside each DinD container so spawned workloads
  # stay on the inner clinic network with local-learning-api and controller.
  docker run -d \
    --name "$container_name" \
    --user 0:0 \
    --privileged \
    --cgroupns host \
    --add-host=host.docker.internal:host-gateway \
    -v /sys/fs/cgroup:/sys/fs/cgroup:rw \
    -v /lib/modules:/lib/modules:ro \
    -v "${docker_volume_name}:/var/lib/docker" \
    -v "$REPO_ROOT:/meta:ro" \
    -v "$dataset_host_path:/connectors/clinic.csv:ro" \
    -v "$CONNECTOR_HOST_PATH:/connectors/us-130-clinics:ro" \
    -e CI_REGISTRY_USER="${CI_REGISTRY_USER:-simon.suewer@uni-hamburg.de}" \
    -e CI_REGISTRY_PASSWORD="${CI_REGISTRY_PASSWORD:-glpat-BEZZaJIPSG8j7uvglydJ6286MQp1OjFsCA.01.0y1tjsn3j}" \
    -e COMPOSE_PROJECT_NAME="$compose_project_name" \
    -e DEPLOYED_ON_ADDRESS="http://localhost:${host_port}" \
    -e DEPLOYED_ON_DOMAIN="localhost" \
    -e GLOBAL_BASE_ADDRESS="dev.federated-learning.net" \
    -e GLOBAL_LEARNING_API_URL="http://host.docker.internal:8080" \
    -e GLOBAL_LEARNING_API_WEBSOCKET_URL="ws://host.docker.internal:8080" \
    -e GLOBAL_SCHEMA_API_URL="https://dev.federated-learning.net/data-modeler" \
    -e GLOBAL_RELAY_HTTP_URL="https://dev.federated-learning.net/relay" \
    -e GLOBAL_RELAY_TCP_ADDRESS="dev.federated-learning.net:9150" \
    -p "${host_port}:80" \
    "$IMAGE_TAG" >/dev/null

  index=$((index + 1))
done

echo "Started ${CLINIC_COUNT} clinic DIND container(s) beginning at port ${START_PORT}."
