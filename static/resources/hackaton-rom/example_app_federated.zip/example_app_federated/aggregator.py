from __future__ import annotations

from typing import Any, Optional

import numpy as np

from pyfedappwrap.engine.federated import AppAggregator, FLNetMessageMetaDTO


class MeanVectorAggregator(AppAggregator):
    def aggregate(
        self,
        data: list[Any],
        n_clients: int,
        meta: Optional[FLNetMessageMetaDTO] = None,
    ) -> Any:
        if not data:
            raise ValueError("Cannot aggregate an empty payload list.")

        if all(isinstance(item, dict) and "coef" in item for item in data):
            return self._aggregate_named(data, n_clients, meta)

        return np.mean(np.stack(data), axis=0)

    @staticmethod
    def _aggregate_named(
        payloads: list[dict[str, Any]],
        n_clients: int,
        meta: Optional[FLNetMessageMetaDTO] = None,
    ) -> dict[str, Any]:
        feature_columns: list[str] = []
        seen: set[str] = set()
        total_samples = 0
        weighted_intercept = 0.0
        weighted_coefficients: dict[str, float] = {}

        for payload in payloads:
            weight = int(payload.get("n_samples", 1))
            total_samples += weight
            weighted_intercept += float(payload.get("intercept", 0.0)) * weight

            for feature, coefficient in payload.get("coef", {}).items():
                if feature not in seen:
                    seen.add(feature)
                    feature_columns.append(feature)
                weighted_coefficients[feature] = (
                    weighted_coefficients.get(feature, 0.0) + float(coefficient) * weight
                )

        divisor = total_samples or n_clients
        return {
            "feature_columns": feature_columns,
            "coef": [
                weighted_coefficients.get(f, 0.0) / divisor for f in feature_columns
            ],
            "intercept": weighted_intercept / divisor,
            "n_clients": n_clients,
            "n_samples": total_samples,
            "round": meta.round if meta else None,
            "communication_id": meta.communication_id if meta else None,
        }
