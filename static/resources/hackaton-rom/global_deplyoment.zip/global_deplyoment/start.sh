#!/bin/sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

REGISTRY="gitlab.cosy.bio:5050"
REGISTRY_USER="${CI_REGISTRY_USER:-simon.suewer@uni-hamburg.de}"
REGISTRY_PASSWORD="${CI_REGISTRY_PASSWORD:-glpat-BEZZaJIPSG8j7uvglydJ6286MQp1OjFsCA.01.0y1tjsn3j}"

echo "Logging into $REGISTRY..."
echo "$REGISTRY_PASSWORD" | docker login --username "$REGISTRY_USER" --password-stdin "$REGISTRY"

echo "Starting global platform on http://localhost:4300 ..."
docker compose up -d

echo ""
echo "Global platform is starting."
echo "  Frontend:  http://localhost:4300"
echo "  API:       http://localhost:4300/api/"
echo "  Keycloak:  http://localhost:4300/auth/"
echo ""
echo "Use 'docker compose logs -f' to follow logs."
