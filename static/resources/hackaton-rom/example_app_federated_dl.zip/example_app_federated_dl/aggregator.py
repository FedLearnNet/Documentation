from __future__ import annotations

from typing import Any, Optional

import numpy as np

from pyfedappwrap.engine.federated import AppAggregator, FLNetMessageMetaDTO


class FedAvgAggregator(AppAggregator):
    """
    FedAvg aggregator for PyTorch models.

    Clients send their model's state_dict as {param_name: flat_list}.
    The aggregator computes a weighted average over all clients and returns
    the averaged state_dict.
    """

    def aggregate(
        self,
        data: list[Any],
        n_clients: int,
        meta: Optional[FLNetMessageMetaDTO] = None,
    ) -> Any:
        if not data:
            raise ValueError("Cannot aggregate an empty payload list.")

        if all(isinstance(item, dict) and "state_dict" in item for item in data):
            return self._fedavg(data, n_clients, meta)

        return np.mean(np.stack(data), axis=0)

    @staticmethod
    def _fedavg(
        payloads: list[dict[str, Any]],
        n_clients: int,
        meta: Optional[FLNetMessageMetaDTO] = None,
    ) -> dict[str, Any]:
        total_samples = sum(int(p.get("n_samples", 1)) for p in payloads)
        divisor = total_samples or n_clients

        avg_state: dict[str, list[float]] = {}

        for payload in payloads:
            weight = int(payload.get("n_samples", 1)) / divisor
            for param_name, values in payload["state_dict"].items():
                arr = np.asarray(values, dtype=float)
                if param_name not in avg_state:
                    avg_state[param_name] = arr * weight
                else:
                    avg_state[param_name] = avg_state[param_name] + arr * weight

        return {
            "state_dict": {k: v.tolist() for k, v in avg_state.items()},
            "n_samples": total_samples,
            "n_clients": n_clients,
            "round": meta.round if meta else None,
        }
