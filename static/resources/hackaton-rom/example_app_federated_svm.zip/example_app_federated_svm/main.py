from pyfedappwrap.engine.runtime import FedDBEngine

from aggregator import WeightAveragingAggregator
from app import FederatedHospitalReadmissionClient

engine = FedDBEngine()

engine.register_aggregator(WeightAveragingAggregator(), "weight_avg")
engine.register_federated(FederatedHospitalReadmissionClient())

if __name__ == '__main__':
    engine.start()
    engine.wait_until_stop()
