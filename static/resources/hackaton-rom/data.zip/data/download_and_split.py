import csv
import shutil
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path


DATASET_URL = "https://archive.ics.uci.edu/static/public/296/diabetes+130-us+hospitals+for+years+1999-2008.zip"
NUM_CLINICS = 130

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "data"
GLOBAL_CSV = OUTPUT_DIR / "diabetic_data.csv"
CLINICS_DIR = OUTPUT_DIR / "clinics"


def download(url: str, target: Path) -> None:
    print("Downloading dataset...")
    with urllib.request.urlopen(url) as response:
        with target.open("wb") as out:
            shutil.copyfileobj(response, out)


def extract(zip_file: Path, target_dir: Path) -> None:
    print("Extracting dataset...")
    with zipfile.ZipFile(zip_file) as zf:
        zf.extractall(target_dir)

    for nested_zip in target_dir.rglob("*.zip"):
        if nested_zip == zip_file:
            continue

        nested_target = nested_zip.parent / nested_zip.stem
        nested_target.mkdir(exist_ok=True)

        with zipfile.ZipFile(nested_zip) as zf:
            zf.extractall(nested_target)


def find_csv(search_dir: Path) -> Path:
    preferred = list(search_dir.rglob("diabetic_data.csv"))
    if preferred:
        return preferred[0]

    csv_files = list(search_dir.rglob("*.csv"))
    if csv_files:
        return csv_files[0]

    raise FileNotFoundError("Could not find diabetic_data.csv in downloaded archive.")


def split_into_clinics(data_csv: Path, clinics_dir: Path) -> None:
    print("Splitting dataset into clinic CSV files...")

    clinics_dir.mkdir(parents=True, exist_ok=True)

    with data_csv.open("r", newline="", encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = list(reader)

    clinic_rows = [[] for _ in range(NUM_CLINICS)]

    for index, row in enumerate(rows):
        clinic_id = index % NUM_CLINICS
        clinic_rows[clinic_id].append(row)

    for clinic_id, rows_for_clinic in enumerate(clinic_rows, start=1):
        clinic_file = clinics_dir / f"clinic_{clinic_id:03d}.csv"

        with clinic_file.open("w", newline="", encoding="utf-8") as out:
            writer = csv.writer(out)
            writer.writerow(header)
            writer.writerows(rows_for_clinic)

    print(f"Created {NUM_CLINICS} clinic CSV files in {clinics_dir}")


def main() -> int:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmp:
        tmp_dir = Path(tmp)
        zip_file = tmp_dir / "dataset.zip"

        try:
            download(DATASET_URL, zip_file)
            extract(zip_file, tmp_dir)

            source_csv = find_csv(tmp_dir)

            print("Storing global dataset...")
            shutil.copyfile(source_csv, GLOBAL_CSV)

            split_into_clinics(GLOBAL_CSV, CLINICS_DIR)

            print("Done.")
            print(f"Global dataset: {GLOBAL_CSV}")
            print(f"Clinic datasets: {CLINICS_DIR}")

            return 0

        except Exception as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1


if __name__ == "__main__":
    raise SystemExit(main())