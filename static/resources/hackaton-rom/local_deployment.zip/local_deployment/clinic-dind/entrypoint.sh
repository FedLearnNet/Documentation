#!/bin/sh
set -e

unset DOCKER_HOST

write_runtime_env() {
  runtime_env="/compose/.env.runtime"
  cp /compose/.env "$runtime_env"

  if [ -z "${HOST_DOCKER_INTERNAL_IP:-}" ]; then
    host_ip="$(
      getent ahostsv4 host.docker.internal 2>/dev/null \
        | awk '$1 ~ /^[0-9.]+$/ {print $1; exit}' \
        || true
    )"
    if [ -z "$host_ip" ]; then
      host_ip="$(
        getent hosts host.docker.internal 2>/dev/null \
          | awk '$1 ~ /^[0-9.]+$/ {print $1; exit}' \
          || true
      )"
    fi
    if [ -n "$host_ip" ]; then
      export HOST_DOCKER_INTERNAL_IP="$host_ip"
    fi
  fi

  for key in \
    EXPOSED_IP_ADDRESS \
    EXPOSED_PORT \
    DEPLOYED_ON_ADDRESS \
    DEPLOYED_ON_DOMAIN \
    HOST_DOCKER_INTERNAL_IP \
    GLOBAL_BASE_ADDRESS \
    GLOBAL_LEARNING_API_URL \
    GLOBAL_LEARNING_API_WEBSOCKET_URL \
    GLOBAL_SCHEMA_API_URL \
    GLOBAL_RELAY_HTTP_URL \
    GLOBAL_RELAY_TCP_ADDRESS \
    COMPOSE_PROFILES \
    SSL_CERT_PUBLIC_KEY \
    SSL_CERT_PRIVATE_KEY \
    FRONTEND_IMAGE \
    COMPOSE_PROJECT_NAME \
    CLINIC_DATASET_PATH \
    CONTAINER_DATASET_PATH \
    CLINIC_CONNECTOR_PATH \
    CONTAINER_CONNECTOR_PATH \
    LOCAL_LEARNING_CONFIG_PATH
  do
    value="$(printenv "$key" 2>/dev/null || true)"
    if [ -n "$value" ]; then
      grep -v "^${key}=" "$runtime_env" > "${runtime_env}.tmp" || true
      printf '%s=%s\n' "$key" "$value" >> "${runtime_env}.tmp"
      mv "${runtime_env}.tmp" "$runtime_env"
    fi
  done

  echo "▷ Inner compose runtime settings:"
  grep -E '^(DEPLOYED_ON_ADDRESS|HOST_DOCKER_INTERNAL_IP|GLOBAL_LEARNING_API_URL|GLOBAL_LEARNING_API_WEBSOCKET_URL|GLOBAL_SCHEMA_API_URL|GLOBAL_RELAY_HTTP_URL|GLOBAL_RELAY_TCP_ADDRESS|COMPOSE_PROJECT_NAME|CLINIC_DATASET_PATH|CONTAINER_DATASET_PATH)=' "$runtime_env" || true
}

echo "▷ Starting Docker daemon..."
dockerd-entrypoint.sh &

echo "▷ Waiting for Docker daemon to be ready..."
timeout=60
until docker info >/dev/null 2>&1; do
  timeout=$((timeout - 1))
  [ "$timeout" -le 0 ] && {
    echo "Docker daemon failed to start in time." >&2
    exit 1
  }
  sleep 1
done

echo "▷ Loading pre-saved images from /compose/images.tar..."
docker load -i /compose/images.tar
echo "▷ Images loaded successfully."
rm -f /compose/images.tar

echo "▷ Logging into registry..."
echo "${CI_REGISTRY_PASSWORD}" \
  | docker login --username "${CI_REGISTRY_USER}" --password-stdin gitlab.cosy.bio:5050

echo "▷ Bringing up clinic stack..."
cd /compose
write_runtime_env
docker compose --env-file /compose/.env.runtime up \
  --attach controller \
  --attach orch-api \
  --attach local-learning-api
