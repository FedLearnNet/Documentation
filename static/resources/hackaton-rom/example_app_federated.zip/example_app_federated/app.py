import os
from pathlib import Path
from typing import Any, Optional

import joblib
import numpy as np
import pandas as pd
from pyfedappwrap.engine.federated import FLNetMessageMetaDTO
from pyfedappwrap.learning.federated import BaseFederatedApp
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split

from config import (
    FederatedHospitalReadmissionConfig,
    HospitalReadmissionInputConfig,
    HospitalReadmissionOutputConfig,
)
from helper import (
    build_prediction_df,
    coef_table,
    generate_explanation_html,
    preprocess_diabetic,
)


def _round_communication_id(base: str, round_nr: int, n_rounds: int) -> str:
    if n_rounds <= 1:
        return base
    if "{round}" in base:
        return base.format(round=round_nr)
    return f"{base}-round-{round_nr}"


class FederatedHospitalReadmissionClient(
    BaseFederatedApp[
        FederatedHospitalReadmissionConfig,
        HospitalReadmissionInputConfig,
        HospitalReadmissionOutputConfig,
    ]
):
    def __init__(self):
        super().__init__()
        self.model: Optional[LogisticRegression] = None
        self.feature_columns: list[str] = []
        self.target_column: str = "hospital_readmission"

    def get_test_data(self) -> Optional[dict[str, Path]]:
        return {"data": Path("data/test_us130_wide.csv")}

    def get_test_hyperparams(self) -> dict[str, Any]:
        return {
            "communication_id": "hospital-readmission",
            "output_filename": "federated_readmission_predictions.csv",
            "federated_rounds": 10,
            "local_max_iter": 50,
            "target_column": "hospital_readmission",
            "standardize": False,
            "C": 1.0,
            "solver": "lbfgs",
            "class_weight": "balanced",
            "random_state": 42,
            "test_size": 0.2,
        }

    def run_train(self, data: HospitalReadmissionInputConfig) -> HospitalReadmissionOutputConfig:
        cfg: FederatedHospitalReadmissionConfig = self.config or FederatedHospitalReadmissionConfig()
        self.target_column = cfg.target_column

        df: pd.DataFrame = data.data
        if df is None:
            raise ValueError("Training data is required.")

        X_initial, y, feature_cols = preprocess_diabetic(df, target_col=cfg.target_column, is_training=True)
        self.feature_columns = feature_cols

        indices = np.arange(len(y))
        train_idx, val_idx = train_test_split(
            indices, test_size=cfg.test_size, random_state=cfg.random_state, stratify=y,
        )

        n_rounds = max(1, int(cfg.federated_rounds))
        local_max_iter = max(1, int(cfg.local_max_iter))
        global_feature_columns: list[str] | None = None
        global_coef: np.ndarray | None = None
        global_intercept = 0.0
        training_history: list[dict[str, float]] = []

        for round_nr in range(1, n_rounds + 1):
            X_all, y_all, round_features = preprocess_diabetic(
                df, target_col=cfg.target_column,
                is_training=global_feature_columns is None,
                feature_columns=global_feature_columns,
            )
            X_train, y_train = X_all[train_idx], y_all[train_idx]

            model = self._new_model(cfg, local_max_iter)
            if global_coef is not None:
                self._prime_model(model, global_coef, global_intercept)
            model.fit(X_train, y_train)

            communication_id = _round_communication_id(cfg.communication_id, round_nr, n_rounds)
            response = self.communicator.aggregate(
                self._model_payload(model, round_features, len(y_train)),
                communication_id=communication_id,
                data_type=dict,
                await_uses_newest_aggregation=False,
                meta=FLNetMessageMetaDTO(
                    communication_id=communication_id,
                    round=round_nr,
                    aggregator="mean",
                ),
            )

            global_feature_columns, global_coef, global_intercept = self._parse_response(
                response.data
            )
            self.feature_columns = global_feature_columns
            self.model = self._new_model(cfg, local_max_iter)
            self._prime_model(self.model, global_coef, global_intercept)

            metrics = self._eval_round(df, y, train_idx, val_idx, round_nr)
            training_history.append(metrics)
            for key, val in metrics.items():
                if key != "x":
                    self.send_metric(key, val, round_nr, "round")

        return self._build_output(df, y, train_idx, val_idx, training_history)

    def run_prediction(self, data: HospitalReadmissionInputConfig) -> HospitalReadmissionOutputConfig:
        self._load("model.joblib")
        df: pd.DataFrame = data.data

        X, y_true, _ = preprocess_diabetic(
            df, target_col=self.target_column, is_training=False, feature_columns=self.feature_columns,
        )

        ids = (
            df["encounter_identifier"].tolist()
            if "encounter_identifier" in df.columns
            else list(range(len(df)))
        )

        y_pred = self.model.predict(X)
        y_proba = self.model.predict_proba(X)[:, 1]
        readmit_rate = float(y_pred.mean())
        self.send_metric("predicted_readmission_rate", readmit_rate, 0)

        pred_df = build_prediction_df(ids, y_pred, y_proba)
        coef_df = coef_table(self.feature_columns, self.model.coef_, self.model.intercept_)
        metrics: dict[str, Any] = {
            "n_samples_prediction": len(y_pred),
            "n_features": X.shape[1],
            "predicted_readmission_rate": readmit_rate,
        }

        if y_true is not None:
            acc = float(accuracy_score(y_true, y_pred))
            auc = float(roc_auc_score(y_true, y_proba))
            prec = float(precision_score(y_true, y_pred, zero_division=0))
            rec = float(recall_score(y_true, y_pred, zero_division=0))
            f1 = float(f1_score(y_true, y_pred, zero_division=0))
            fpr, tpr, _ = roc_curve(y_true, y_proba)
            cm = confusion_matrix(y_true, y_pred).tolist()
            report_str = classification_report(
                y_true, y_pred, target_names=["Not Readmitted", "Readmitted <30d"], zero_division=0,
            )
            metrics.update(prediction_accuracy=acc, prediction_auc=auc,
                           prediction_precision=prec, prediction_recall=rec, prediction_f1=f1)
            report = (
                f"Prediction complete — {len(y_pred)} samples\n"
                f"Readmission rate: {readmit_rate:.1%}\n"
                f"  Accuracy: {acc:.4f}  AUC: {auc:.4f}  F1: {f1:.4f}\n"
            )
        else:
            cm, report_str, fpr, tpr = [[0, 0], [0, 0]], "", None, None
            report = f"Prediction complete — {len(y_pred)} samples, rate: {readmit_rate:.1%}"

        explanation_path = Path(f"output/federated_prediction_{self._safe_name()}.html")
        explanation_path.write_text(
            generate_explanation_html(coef_df, metrics, cm, report_str,
                                     training_history=[], top_k=20, val_fpr=fpr, val_tpr=tpr),
            encoding="utf-8",
        )

        return HospitalReadmissionOutputConfig(
            predictions=pred_df, coefficients=coef_df, explanation=explanation_path, report=report,
        )

    # --- Private helpers ---

    @staticmethod
    def _new_model(cfg, max_iter: int) -> LogisticRegression:
        cw = None if cfg.class_weight == "none" else cfg.class_weight
        return LogisticRegression(
            C=cfg.C, solver=cfg.solver, max_iter=max(1, int(max_iter)),
            class_weight=cw, random_state=cfg.random_state, warm_start=True,
        )

    @staticmethod
    def _prime_model(model: LogisticRegression, coef: np.ndarray, intercept: float) -> None:
        model.classes_ = np.array([0, 1])
        model.coef_ = np.asarray([coef], dtype=float)
        model.intercept_ = np.asarray([intercept], dtype=float)
        model.n_features_in_ = len(coef)

    @staticmethod
    def _model_payload(model: LogisticRegression, features: list[str], n_samples: int) -> dict:
        return {
            "coef": {f: float(c) for f, c in zip(features, model.coef_[0])},
            "intercept": float(model.intercept_[0]),
            "n_samples": n_samples,
        }

    @staticmethod
    def _parse_response(payload: dict[str, Any]) -> tuple[list[str], np.ndarray, float]:
        features = [str(f) for f in payload.get("feature_columns", [])]
        coef = np.asarray(payload.get("coef", []), dtype=float)
        intercept = float(payload.get("intercept", 0.0))
        if len(features) != len(coef):
            raise ValueError("Mismatched feature/coefficient lengths in aggregated payload.")
        return features, coef, intercept

    def _eval_round(self, df, y, train_idx, val_idx, round_nr) -> dict[str, float]:
        X_all, _, _ = preprocess_diabetic(
            df, target_col=self.target_column, is_training=False, feature_columns=self.feature_columns,
        )
        y_train, y_val = y[train_idx], y[val_idx]
        train_proba = self.model.predict_proba(X_all[train_idx])[:, 1]
        val_pred = self.model.predict(X_all[val_idx])
        val_proba = self.model.predict_proba(X_all[val_idx])[:, 1]
        return {
            "x": float(round_nr),
            "train_accuracy": float(accuracy_score(y_train, self.model.predict(X_all[train_idx]))),
            "val_accuracy": float(accuracy_score(y_val, val_pred)),
            "train_auc": float(roc_auc_score(y_train, train_proba)),
            "val_auc": float(roc_auc_score(y_val, val_proba)),
        }

    def _build_output(self, df, y, train_idx, val_idx, history) -> HospitalReadmissionOutputConfig:
        X_all, _, _ = preprocess_diabetic(
            df, target_col=self.target_column, is_training=False, feature_columns=self.feature_columns,
        )
        y_train, y_val = y[train_idx], y[val_idx]
        val_pred = self.model.predict(X_all[val_idx])
        val_proba = self.model.predict_proba(X_all[val_idx])[:, 1]
        val_fpr, val_tpr, _ = roc_curve(y_val, val_proba)

        metrics = {
            "n_samples_train": len(y_train),
            "n_samples_val": len(y_val),
            "n_features": X_all.shape[1],
            "federated_rounds": len(history),
            "train_accuracy": float(accuracy_score(y_train, self.model.predict(X_all[train_idx]))),
            "val_accuracy": float(accuracy_score(y_val, val_pred)),
            "train_auc": float(roc_auc_score(y_train, self.model.predict_proba(X_all[train_idx])[:, 1])),
            "val_auc": float(roc_auc_score(y_val, val_proba)),
            "val_precision": float(precision_score(y_val, val_pred, zero_division=0)),
            "val_recall": float(recall_score(y_val, val_pred, zero_division=0)),
            "val_f1": float(f1_score(y_val, val_pred, zero_division=0)),
        }

        for key in ("val_accuracy", "val_auc", "val_precision", "val_recall", "val_f1",
                    "train_accuracy", "train_auc"):
            prefix = "final_" if key.startswith(("val_", "train_")) else ""
            self.send_metric(f"{prefix}{key}", metrics[key], len(history), "round")

        coef_df = coef_table(self.feature_columns, self.model.coef_, self.model.intercept_)
        val_cm = confusion_matrix(y_val, val_pred).tolist()
        val_report = classification_report(
            y_val, val_pred, target_names=["Not Readmitted", "Readmitted <30d"], zero_division=0,
        )

        explanation_path = Path(f"output/federated_explanation_{self._safe_name()}.html")
        explanation_path.write_text(
            generate_explanation_html(
                coef_df, metrics, val_cm, val_report,
                training_history=history, top_k=20, val_fpr=val_fpr, val_tpr=val_tpr,
            ),
            encoding="utf-8",
        )

        pred_df = build_prediction_df(val_idx.tolist(), val_pred, val_proba)
        report = (
            f"Federated Training Summary\n{'=' * 40}\n"
            f"Samples: {metrics['n_samples_train']} train / {metrics['n_samples_val']} val\n"
            f"Features: {metrics['n_features']}, Rounds: {metrics['federated_rounds']}\n"
            f"Val — Acc: {metrics['val_accuracy']:.4f}, AUC: {metrics['val_auc']:.4f}, "
            f"F1: {metrics['val_f1']:.4f}\n"
        )
        if self.logger:
            self.logger.info(report)

        self._save()
        cfg = self.config or FederatedHospitalReadmissionConfig()
        self.save_local_csv(pred_df, cfg.output_filename)

        return HospitalReadmissionOutputConfig(
            predictions=pred_df, coefficients=coef_df, explanation=explanation_path, report=report,
        )

    def _safe_name(self) -> str:
        text = str(self.app_id or "client")
        return "".join(c if c.isalnum() or c in "-_" else "_" for c in text)

    def _save(self) -> str:
        model_dir = os.environ.get("MODEL_DIR", "./model/")
        path = Path(model_dir) / "model.joblib"
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({
            "model": self.model,
            "feature_columns": self.feature_columns,
            "target_column": self.target_column,
        }, path)
        return "model.joblib"

    def _load(self, path: str) -> None:
        if self.model is not None:
            return
        model_dir = os.environ.get("MODEL_DIR", "./model/")
        artifact = joblib.load(Path(model_dir) / path)
        self.model = artifact["model"]
        self.feature_columns = artifact["feature_columns"]
        self.target_column = artifact["target_column"]
