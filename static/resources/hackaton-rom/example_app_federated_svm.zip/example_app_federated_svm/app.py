import os
from pathlib import Path
from typing import Any, Optional

import joblib
import numpy as np
import pandas as pd
from pyfedappwrap.engine.federated import FLNetMessageMetaDTO
from pyfedappwrap.learning.federated import BaseFederatedApp
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from config import (
    FederatedHospitalReadmissionConfig,
    HospitalReadmissionInputConfig,
    HospitalReadmissionOutputConfig,
)
from helper import build_prediction_df, generate_explanation_html, preprocess_diabetic


def _round_id(base: str, round_nr: int, n_rounds: int) -> str:
    if n_rounds <= 1:
        return base
    if "{round}" in base:
        return base.format(round=round_nr)
    return f"{base}-round-{round_nr}"


class FederatedHospitalReadmissionClient(
    BaseFederatedApp[
        FederatedHospitalReadmissionConfig,
        HospitalReadmissionInputConfig,
        HospitalReadmissionOutputConfig,
    ]
):
    """
    Federated SVM client using SGDClassifier (linear SVM via stochastic gradient descent).

    Each round:
      1. Client trains locally for `local_epochs` passes over its data.
      2. Sends model weights (coef + intercept) to the aggregator.
      3. Receives FedAvg-averaged global weights and sets them as the new starting point.

    This is the standard FedAvg approach — works because linear SVMs have explicit weight vectors.
    Note: features must be standardized before training (done locally per client).
    """

    def __init__(self):
        super().__init__()
        self.model: Optional[SGDClassifier] = None
        self.scaler: Optional[StandardScaler] = None
        self.feature_columns: list[str] = []
        self.target_column: str = "hospital_readmission"

    def get_test_data(self) -> Optional[dict[str, Path]]:
        return {"data": Path("data/test_us130_wide.csv")}

    def get_test_hyperparams(self) -> dict[str, Any]:
        return {
            "communication_id": "hospital-readmission-svm",
            "output_filename": "federated_svm_predictions.csv",
            "federated_rounds": 10,
            "local_epochs": 5,
            "alpha": 0.0001,
            "class_weight": "balanced",
            "random_state": 42,
            "test_size": 0.2,
        }

    def run_train(self, data: HospitalReadmissionInputConfig) -> HospitalReadmissionOutputConfig:
        cfg: FederatedHospitalReadmissionConfig = self.config or FederatedHospitalReadmissionConfig()
        self.target_column = cfg.target_column

        df: pd.DataFrame = data.data
        if df is None:
            raise ValueError("Training data is required.")

        X, y, feature_cols = preprocess_diabetic(df, target_col=cfg.target_column, is_training=True)
        self.feature_columns = feature_cols

        # Scale locally — each client scales its own data
        self.scaler = StandardScaler()
        X = self.scaler.fit_transform(X)

        indices = np.arange(len(y))
        train_idx, val_idx = train_test_split(
            indices, test_size=cfg.test_size, random_state=cfg.random_state, stratify=y,
        )

        n_rounds = max(1, int(cfg.federated_rounds))
        local_epochs = max(1, int(cfg.local_epochs))
        class_weight = None if cfg.class_weight == "none" else cfg.class_weight

        # modified_huber: smooth approximation of hinge, supports predict_proba
        self.model = SGDClassifier(
            loss="modified_huber",
            alpha=cfg.alpha,
            class_weight=class_weight,
            random_state=cfg.random_state,
            warm_start=True,
            max_iter=local_epochs,
        )

        X_train, y_train = X[train_idx], y[train_idx]
        global_coef: np.ndarray | None = None
        global_intercept = 0.0
        training_history: list[dict[str, float]] = []

        for round_nr in range(1, n_rounds + 1):
            if global_coef is not None:
                self._set_weights(self.model, global_coef, global_intercept)

            self.model.fit(X_train, y_train)

            communication_id = _round_id(cfg.communication_id, round_nr, n_rounds)
            response = self.communicator.aggregate(
                self._payload(self.model, self.feature_columns, len(y_train)),
                communication_id=communication_id,
                data_type=dict,
                await_uses_newest_aggregation=False,
                meta=FLNetMessageMetaDTO(
                    communication_id=communication_id,
                    round=round_nr,
                    aggregator="weight_avg",
                ),
            )

            global_coef, global_intercept = self._parse_response(response.data)
            self._set_weights(self.model, global_coef, global_intercept)

            metrics = self._eval(X, y, train_idx, val_idx, round_nr)
            training_history.append(metrics)
            for key, val in metrics.items():
                if key != "x":
                    self.send_metric(key, val, round_nr, "round")

            self.logger.info(
                f"Round {round_nr}/{n_rounds} — "
                f"val_acc={metrics['val_accuracy']:.4f}  val_auc={metrics['val_auc']:.4f}"
            )

        return self._build_output(X, y, train_idx, val_idx, training_history, cfg)

    def run_prediction(self, data: HospitalReadmissionInputConfig) -> HospitalReadmissionOutputConfig:
        self._load("model.joblib")
        df: pd.DataFrame = data.data

        X, y_true, _ = preprocess_diabetic(
            df, target_col=self.target_column, is_training=False,
            feature_columns=self.feature_columns,
        )
        X = self.scaler.transform(X)

        ids = (df["encounter_identifier"].tolist()
               if "encounter_identifier" in df.columns else list(range(len(df))))

        y_pred = self.model.predict(X)
        y_proba = self.model.predict_proba(X)[:, 1]
        readmit_rate = float(y_pred.mean())
        self.send_metric("predicted_readmission_rate", readmit_rate, 0)

        pred_df = build_prediction_df(ids, y_pred, y_proba)
        metrics: dict[str, Any] = {
            "n_samples_prediction": len(y_pred),
            "n_features": X.shape[1],
            "predicted_readmission_rate": readmit_rate,
        }

        if y_true is not None:
            acc = float(accuracy_score(y_true, y_pred))
            auc = float(roc_auc_score(y_true, y_proba))
            prec = float(precision_score(y_true, y_pred, zero_division=0))
            rec = float(recall_score(y_true, y_pred, zero_division=0))
            f1 = float(f1_score(y_true, y_pred, zero_division=0))
            cm = confusion_matrix(y_true, y_pred).tolist()
            rep_str = classification_report(y_true, y_pred,
                                            target_names=["Not Readmitted", "Readmitted <30d"],
                                            zero_division=0)
            fpr, tpr, _ = roc_curve(y_true, y_proba)
            metrics.update(prediction_accuracy=acc, prediction_auc=auc,
                           prediction_precision=prec, prediction_recall=rec, prediction_f1=f1)
            report = f"Prediction — {len(y_pred)} samples, rate: {readmit_rate:.1%}\n" \
                     f"  Accuracy: {acc:.4f}  AUC: {auc:.4f}  F1: {f1:.4f}\n"
        else:
            cm, rep_str, fpr, tpr = [[0, 0], [0, 0]], "", None, None
            report = f"Prediction — {len(y_pred)} samples, rate: {readmit_rate:.1%}"

        explanation_path = Path(f"output/federated_svm_prediction_{self._safe_name()}.html")
        explanation_path.write_text(
            generate_explanation_html(metrics, cm, rep_str, val_fpr=fpr, val_tpr=tpr),
            encoding="utf-8",
        )

        return HospitalReadmissionOutputConfig(
            predictions=pred_df, explanation=explanation_path, report=report,
        )

    # --- Private helpers ---

    @staticmethod
    def _payload(model: SGDClassifier, features: list[str], n_samples: int) -> dict:
        return {
            "coef": {f: float(c) for f, c in zip(features, model.coef_[0])},
            "intercept": float(model.intercept_[0]),
            "n_samples": n_samples,
        }

    @staticmethod
    def _set_weights(model: SGDClassifier, coef: np.ndarray, intercept: float) -> None:
        model.classes_ = np.array([0, 1])
        model.coef_ = np.asarray([coef], dtype=float)
        model.intercept_ = np.asarray([intercept], dtype=float)
        model.n_features_in_ = len(coef)

    @staticmethod
    def _parse_response(payload: dict) -> tuple[np.ndarray, float]:
        features = [str(f) for f in payload.get("feature_columns", [])]
        coef = np.asarray(payload.get("coef", []), dtype=float)
        intercept = float(payload.get("intercept", 0.0))
        return coef, intercept

    def _eval(self, X, y, train_idx, val_idx, round_nr) -> dict[str, float]:
        y_train, y_val = y[train_idx], y[val_idx]
        train_proba = self.model.predict_proba(X[train_idx])[:, 1]
        val_pred = self.model.predict(X[val_idx])
        val_proba = self.model.predict_proba(X[val_idx])[:, 1]
        return {
            "x": float(round_nr),
            "train_accuracy": float(accuracy_score(y_train, self.model.predict(X[train_idx]))),
            "val_accuracy": float(accuracy_score(y_val, val_pred)),
            "train_auc": float(roc_auc_score(y_train, train_proba)),
            "val_auc": float(roc_auc_score(y_val, val_proba)),
        }

    def _build_output(self, X, y, train_idx, val_idx, history, cfg) -> HospitalReadmissionOutputConfig:
        y_train, y_val = y[train_idx], y[val_idx]
        val_pred = self.model.predict(X[val_idx])
        val_proba = self.model.predict_proba(X[val_idx])[:, 1]
        val_fpr, val_tpr, _ = roc_curve(y_val, val_proba)

        metrics = {
            "n_samples_train": len(y_train),
            "n_samples_val": len(y_val),
            "n_features": X.shape[1],
            "federated_rounds": len(history),
            "train_accuracy": float(accuracy_score(y_train, self.model.predict(X[train_idx]))),
            "val_accuracy": float(accuracy_score(y_val, val_pred)),
            "train_auc": float(roc_auc_score(y_train, self.model.predict_proba(X[train_idx])[:, 1])),
            "val_auc": float(roc_auc_score(y_val, val_proba)),
            "val_precision": float(precision_score(y_val, val_pred, zero_division=0)),
            "val_recall": float(recall_score(y_val, val_pred, zero_division=0)),
            "val_f1": float(f1_score(y_val, val_pred, zero_division=0)),
        }

        for key in ("val_accuracy", "val_auc", "val_precision", "val_recall", "val_f1",
                    "train_accuracy", "train_auc"):
            self.send_metric(f"final_{key}", metrics[key], len(history), "round")

        val_cm = confusion_matrix(y_val, val_pred).tolist()
        val_report = classification_report(y_val, val_pred,
                                           target_names=["Not Readmitted", "Readmitted <30d"],
                                           zero_division=0)

        explanation_path = Path(f"output/federated_svm_explanation_{self._safe_name()}.html")
        explanation_path.write_text(
            generate_explanation_html(
                metrics, val_cm, val_report,
                training_history=history, val_fpr=val_fpr, val_tpr=val_tpr,
            ),
            encoding="utf-8",
        )

        pred_df = build_prediction_df(val_idx.tolist(), val_pred, val_proba)
        report = (
            f"Federated SVM (SGD) Summary\n{'=' * 40}\n"
            f"Samples: {metrics['n_samples_train']} train / {metrics['n_samples_val']} val\n"
            f"Features: {metrics['n_features']}, Rounds: {metrics['federated_rounds']}\n"
            f"Val — Acc: {metrics['val_accuracy']:.4f}, AUC: {metrics['val_auc']:.4f}, "
            f"F1: {metrics['val_f1']:.4f}\n"
        )
        if self.logger:
            self.logger.info(report)

        self._save()
        self.save_local_csv(pred_df, cfg.output_filename)

        return HospitalReadmissionOutputConfig(
            predictions=pred_df, explanation=explanation_path, report=report,
        )

    def _safe_name(self) -> str:
        text = str(self.app_id or "client")
        return "".join(c if c.isalnum() or c in "-_" else "_" for c in text)

    def _save(self) -> str:
        model_dir = os.environ.get("MODEL_DIR", "./model/")
        path = Path(model_dir) / "model.joblib"
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({
            "model": self.model,
            "scaler": self.scaler,
            "feature_columns": self.feature_columns,
            "target_column": self.target_column,
        }, path)
        return "model.joblib"

    def _load(self, path: str) -> None:
        if self.model is not None:
            return
        model_dir = os.environ.get("MODEL_DIR", "./model/")
        artifact = joblib.load(Path(model_dir) / path)
        self.model = artifact["model"]
        self.scaler = artifact["scaler"]
        self.feature_columns = artifact["feature_columns"]
        self.target_column = artifact["target_column"]
