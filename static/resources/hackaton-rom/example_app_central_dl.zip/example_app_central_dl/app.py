import os
from pathlib import Path
from typing import Optional

import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from pyfedappwrap.learning.base_app import BaseApp
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from config import (
    HospitalReadmissionConfig,
    HospitalReadmissionInputConfig,
    HospitalReadmissionOutputConfig,
)
from helper import MLP, build_prediction_df, generate_explanation_html, preprocess_diabetic


class HospitalReadmissionApp(
    BaseApp[
        HospitalReadmissionConfig,
        HospitalReadmissionInputConfig,
        HospitalReadmissionOutputConfig,
    ]
):
    def __init__(self):
        super().__init__()
        self.model: Optional[MLP] = None
        self.scaler: Optional[StandardScaler] = None
        self.feature_columns: list[str] = []
        self.target_column: str = "hospital_readmission"

    def get_test_data(self) -> Optional[dict[str, Path]]:
        return {"data": Path("data/test_us130_wide.csv")}

    def run_train(self, data: HospitalReadmissionInputConfig) -> HospitalReadmissionOutputConfig:
        self.logger.info("Running train (MLP / Deep Learning)")
        cfg: HospitalReadmissionConfig = self.config
        self.target_column = cfg.target_column

        torch.manual_seed(cfg.random_state)
        np.random.seed(cfg.random_state)

        df: pd.DataFrame = data.data
        self.logger.info(f"Dataset: {df.shape[0]} rows x {df.shape[1]} columns")

        X, y, feature_cols = preprocess_diabetic(df, target_col=cfg.target_column, is_training=True)
        self.feature_columns = feature_cols

        X_train, X_val, y_train, y_val = train_test_split(
            X, y, test_size=cfg.test_size, random_state=cfg.random_state, stratify=y,
        )
        self.logger.info(f"Train/val split: {len(y_train)} / {len(y_val)}")

        self.scaler = StandardScaler()
        X_train = self.scaler.fit_transform(X_train)
        X_val = self.scaler.transform(X_val)

        n_features = X_train.shape[1]
        self.model = MLP(n_features, cfg.hidden_dim, cfg.n_layers, cfg.dropout)
        self.logger.info(f"Model: {self.model}")

        # Class weights to handle imbalance
        n_pos = int(y_train.sum())
        n_neg = len(y_train) - n_pos
        pos_weight = torch.tensor([n_neg / max(n_pos, 1)], dtype=torch.float32)
        criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
        optimizer = optim.Adam(self.model.parameters(), lr=cfg.learning_rate)

        X_t = torch.from_numpy(X_train).float()
        y_t = torch.from_numpy(y_train).float()
        X_v = torch.from_numpy(X_val).float()

        training_history: list[dict] = []

        for epoch in range(1, cfg.epochs + 1):
            self.model.train()
            # Mini-batch training
            perm = torch.randperm(len(X_t))
            epoch_loss = 0.0
            for i in range(0, len(X_t), cfg.batch_size):
                batch_idx = perm[i:i + cfg.batch_size]
                xb, yb = X_t[batch_idx], y_t[batch_idx]
                optimizer.zero_grad()
                logits = self.model(xb).squeeze(1)
                loss = criterion(logits, yb)
                loss.backward()
                optimizer.step()
                epoch_loss += loss.item() * len(xb)
            epoch_loss /= len(X_t)

            self.model.eval()
            with torch.no_grad():
                train_proba = torch.sigmoid(self.model(X_t).squeeze(1)).numpy()
                val_proba = torch.sigmoid(self.model(X_v).squeeze(1)).numpy()

            train_pred = (train_proba >= 0.5).astype(int)
            val_pred = (val_proba >= 0.5).astype(int)

            train_acc = float(accuracy_score(y_train, train_pred))
            val_acc = float(accuracy_score(y_val, val_pred))
            train_auc = float(roc_auc_score(y_train, train_proba))
            val_auc = float(roc_auc_score(y_val, val_proba))

            self.send_metric("train_loss", epoch_loss, epoch)
            self.send_metric("train_accuracy", train_acc, epoch)
            self.send_metric("val_accuracy", val_acc, epoch)
            self.send_metric("train_auc", train_auc, epoch)
            self.send_metric("val_auc", val_auc, epoch)

            training_history.append({
                "x": epoch,
                "train_accuracy": train_acc,
                "val_accuracy": val_acc,
                "train_auc": train_auc,
                "val_auc": val_auc,
            })

            self.logger.info(
                f"Epoch {epoch}/{cfg.epochs} — loss={epoch_loss:.4f}  "
                f"val_acc={val_acc:.4f}  val_auc={val_auc:.4f}"
            )

        self.model.eval()
        with torch.no_grad():
            val_proba_np = torch.sigmoid(self.model(X_v).squeeze(1)).numpy()
        val_pred_np = (val_proba_np >= 0.5).astype(int)
        val_fpr, val_tpr, _ = roc_curve(y_val, val_proba_np)

        val_accuracy = float(accuracy_score(y_val, val_pred_np))
        val_auc = float(roc_auc_score(y_val, val_proba_np))
        val_precision = float(precision_score(y_val, val_pred_np, zero_division=0))
        val_recall = float(recall_score(y_val, val_pred_np, zero_division=0))
        val_f1 = float(f1_score(y_val, val_pred_np, zero_division=0))

        with torch.no_grad():
            train_proba_np = torch.sigmoid(self.model(X_t).squeeze(1)).numpy()
        train_accuracy = float(accuracy_score(y_train, (train_proba_np >= 0.5).astype(int)))
        train_auc_final = float(roc_auc_score(y_train, train_proba_np))

        metrics = {
            "n_samples_train": len(y_train),
            "n_samples_val": len(y_val),
            "n_features": n_features,
            "epochs": cfg.epochs,
            "train_accuracy": train_accuracy,
            "val_accuracy": val_accuracy,
            "train_auc": train_auc_final,
            "val_auc": val_auc,
            "val_precision": val_precision,
            "val_recall": val_recall,
            "val_f1": val_f1,
        }

        val_cm = confusion_matrix(y_val, val_pred_np).tolist()
        val_report = classification_report(y_val, val_pred_np,
                                           target_names=["Not Readmitted", "Readmitted <30d"])
        self.logger.info(f"Classification Report:\n{val_report}")

        explanation_path = Path("output/explanation.html")
        explanation_path.write_text(
            generate_explanation_html(metrics, val_cm, val_report,
                                      training_history=training_history,
                                      val_fpr=val_fpr, val_tpr=val_tpr),
            encoding="utf-8",
        )

        pred_df = build_prediction_df(list(range(len(y_val))), val_pred_np, val_proba_np)
        report = (
            "Hospital Readmission (MLP) — Training Summary\n"
            f"{'=' * 50}\n"
            f"Samples   : {len(y_train)} train / {len(y_val)} val\n"
            f"Features  : {n_features}\n"
            f"Epochs    : {cfg.epochs}\n"
            f"\nValidation:\n"
            f"  Accuracy: {val_accuracy:.4f}\n"
            f"  AUC-ROC : {val_auc:.4f}\n"
            f"  F1-Score: {val_f1:.4f}\n"
        )
        self.logger.info(report)
        self._save()

        return HospitalReadmissionOutputConfig(
            predictions=pred_df, explanation=explanation_path, report=report,
        )

    def run_prediction(self, data: HospitalReadmissionInputConfig) -> HospitalReadmissionOutputConfig:
        self._load("model.joblib")
        self.logger.info("Running prediction (MLP)")
        df: pd.DataFrame = data.data

        X, y_true, _ = preprocess_diabetic(
            df, target_col=self.target_column, is_training=False,
            feature_columns=self.feature_columns,
        )
        X = self.scaler.transform(X)

        ids = (df["encounter_identifier"].tolist()
               if "encounter_identifier" in df.columns else list(range(len(df))))

        self.model.eval()
        with torch.no_grad():
            X_t = torch.from_numpy(X).float()
            y_proba = torch.sigmoid(self.model(X_t).squeeze(1)).numpy()
        y_pred = (y_proba >= 0.5).astype(int)
        readmit_rate = float(y_pred.mean())
        self.send_metric("predicted_readmission_rate", readmit_rate, 0)

        pred_df = build_prediction_df(ids, y_pred, y_proba)
        metrics = {"n_samples_prediction": len(y_pred), "n_features": X.shape[1],
                   "predicted_readmission_rate": readmit_rate}

        if y_true is not None:
            acc = float(accuracy_score(y_true, y_pred))
            auc = float(roc_auc_score(y_true, y_proba))
            f1 = float(f1_score(y_true, y_pred, zero_division=0))
            cm = confusion_matrix(y_true, y_pred).tolist()
            rep_str = classification_report(y_true, y_pred,
                                            target_names=["Not Readmitted", "Readmitted <30d"],
                                            zero_division=0)
            fpr, tpr, _ = roc_curve(y_true, y_proba)
            metrics.update(prediction_accuracy=acc, prediction_auc=auc, prediction_f1=f1)
            report = f"Prediction — {len(y_pred)} samples, rate: {readmit_rate:.1%}\n" \
                     f"  Accuracy: {acc:.4f}  AUC: {auc:.4f}  F1: {f1:.4f}\n"
        else:
            cm, rep_str, fpr, tpr = [[0, 0], [0, 0]], "", None, None
            report = f"Prediction — {len(y_pred)} samples, rate: {readmit_rate:.1%}"

        explanation_path = Path("prediction_explanation.html")
        explanation_path.write_text(
            generate_explanation_html(metrics, cm, rep_str, val_fpr=fpr, val_tpr=tpr),
            encoding="utf-8",
        )
        self.logger.info(report)

        return HospitalReadmissionOutputConfig(
            predictions=pred_df, explanation=explanation_path, report=report,
        )

    def _save(self) -> str:
        model_dir = os.environ.get("MODEL_DIR", "./model/")
        path = Path(model_dir) / "model.joblib"
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({
            "model_state": self.model.state_dict(),
            "model_arch": {"n_features": self.model.net[0].in_features,
                           "hidden_dim": self.model.hidden_dim,
                           "n_layers": self.model.n_layers,
                           "dropout": self.model.dropout_rate},
            "scaler": self.scaler,
            "feature_columns": self.feature_columns,
            "target_column": self.target_column,
        }, path)
        self.logger.info(f"Artifact saved -> {path}")
        return "model.joblib"

    def _load(self, path: str) -> None:
        if self.model is not None:
            return
        model_dir = os.environ.get("MODEL_DIR", "./model/")
        artifact = joblib.load(Path(model_dir) / path)
        arch = artifact["model_arch"]
        self.model = MLP(arch["n_features"], arch["hidden_dim"],
                         arch["n_layers"], arch["dropout"])
        self.model.load_state_dict(artifact["model_state"])
        self.model.eval()
        self.scaler = artifact["scaler"]
        self.feature_columns = artifact["feature_columns"]
        self.target_column = artifact["target_column"]
        self.logger.info(f"Artifact loaded <- {path}")
