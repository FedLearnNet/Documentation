#!/bin/sh
set -euo pipefail

COMPOSE_FILE="docker-compose.yml"
TARFILE="images.tar"

echo "▷ Extracting image names from $COMPOSE_FILE"
images=$(grep '^\s*image:' "$COMPOSE_FILE" \
         | awk '{print $2}' \
         | sort -u)

if [ -z "$images" ]; then
  echo "❌ No images found in $COMPOSE_FILE" >&2
  exit 1
fi

for img in $images; do
  echo "  • Pulling $img"
  docker pull "$img"
done

docker save $images -o "$TARFILE"
echo "▷ Saved images to $TARFILE"



