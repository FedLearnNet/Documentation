# Deployment

## Prerequisite
Deployment is done using docker compose. Therefore, [Docker](https://www.docker.com/)
and [docker compose](https://docs.docker.com/compose/) should be installed.

## Actually deployed instances
In the `currently-deployed` folder, there is one folder for each server. In each servers folder, 
e.g. in `staging.featurecloud.ai`, what is deployed on that server can be found.
This serves for documentation and is also used on the servers. If anything is updated in these
servers, you need to manually docker compose down and up on the servers for the 
changes to take effect!

## Development deployment
TODO: recreate these folders and maybe think of something for deploying multiple clinics and data addition etc

The `clinic` and `platform` folder bring everything necessary to startup one docker network with 
all services of a clinic node or of the platform. Whatever feature implemented should work
in that environment!

In the `clinic` and `platform` folder are a `docker-compose.yml` file, an `.env` file for 
the general environment of the whole compose project as well as one `<service>.env` file per
service for each specfic service (e.g. datamodeler, local-learning-api, ...).

The `.env` file are general settings on how the `clinic`/`platform` should be deployed.
This also includes the address of the platform the clinic connects to!
Docker compose up automatically uses files called `.env` and files called `docker-compose.yml`, 
so you can just call `docker compose up -d`.
If you want to deploy to clinics, the `clinic` folder also contains another `clinic2.env` file 
you can use to start another clinic.
```
docker compose up -d
  # starts clinic 1
docker compose up -d --env-file=clinic2.env
  # starts clinic2
```

The `compose file` can be used to e.g. use another docker image that you built locally and want 
to test. You can for that simply build the image locally with another tag, e.g. :tmptag, use
that tmptag in the `compose file` and after rebuilding the image just restart your service with
--pull=always.

If you want to change the network name, please use ctrl+f to replace it also in the relevant 
env files, e.g. orch-api and learning-api env files.

Try to avoid changing exposed ports.

The relevant frontends are available on the ports exposed by the nginx, which should be:

1. clinic: http://localhost:4701
2. platform: http://localhost:8250

## How can you deploy
### Option 1: deploying an example clinic connecting to a globally deployed instance
Just go to the `clinic` folder.

Check the `.env` file there, there is specified to which global services the local side connects to.
Change the variables accordingly if they are incorrect, per default they point to the locally deployed platform!
Then, simply run:
```
docker compose up -d
```
Please note that this tries to connect to a locally deployed platform, change the .env files
accordingly if you want to use globally deployed services.

### Option 2: deploying an example platform without any connected clinics
Just go to the `platform` folder.

Then, simply run:
```
docker compose up -d
```

### Option 3: deploying an example clinic and platform that interact with each other.
First go to the `platform` folder.
Run:
```
docker compose up -d
```
Wait for it to have started, check which is the exposed port of 
the nginx service in `docker-compose.yml`.

Now, go to the `clinic` folder.
Check the `.env` file there, there is specified to which global services the local side connects to.
Make sure they connect to `docker.host.internal:<the platforms nginxes exposed port>` for all services
with the correct path, that should be correct already, but you can double check with the 
nginx configuration in the `platform` folder!
Then, simply run:
```
docker compose up -d
```
