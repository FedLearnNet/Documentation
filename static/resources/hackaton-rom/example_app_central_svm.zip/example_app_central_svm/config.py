from pathlib import Path
from typing import Any

from pydantic.dataclasses import dataclass
from pyfedappwrap.learning.run_runfig import AppConfig, AppInputConfig, AppOutputConfig


@dataclass
class HospitalReadmissionConfig(AppConfig):
    target_column: str = "hospital_readmission"
    C: float = 1.0
    kernel: str = "rbf"
    gamma: str = "scale"
    class_weight: str = "balanced"
    random_state: int = 42
    test_size: float = 0.2
    max_iter: int = 1000


@dataclass
class HospitalReadmissionInputConfig(AppInputConfig):
    data: Any = None


@dataclass
class HospitalReadmissionOutputConfig(AppOutputConfig):
    predictions: Any | None = None
    explanation: Path | None = None
    report: str | None = None
