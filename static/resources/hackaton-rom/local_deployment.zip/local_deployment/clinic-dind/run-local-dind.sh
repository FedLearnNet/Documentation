#!/bin/sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
HOST_PORT="${HOST_PORT:-4601}"
DEPLOYED_ON_ADDRESS="${DEPLOYED_ON_ADDRESS:-http://localhost:${HOST_PORT}}"
COMPOSE_PROJECT_NAME="${COMPOSE_PROJECT_NAME:-fl-net-clinic1}"
CLINIC_DATASET_PATH="${CLINIC_DATASET_PATH:-$REPO_ROOT/deployment/example-data/us-130/clinics/clinic_001.csv}"
CLINIC_CONNECTOR_PATH="${CLINIC_CONNECTOR_PATH:-$SCRIPT_DIR/us-130-clinics.json}"

if [ ! -f "$CLINIC_DATASET_PATH" ]; then
  echo "Missing dataset: $CLINIC_DATASET_PATH" >&2
  exit 1
fi

if [ ! -f "$CLINIC_CONNECTOR_PATH" ]; then
  echo "Missing connector config: $CLINIC_CONNECTOR_PATH" >&2
  exit 1
fi

# Keep the Docker daemon inside the DinD container so orch-api spawns onto
# the inner clinic network with local-learning-api and controller.
docker run -it \
  --name clinic-dind \
  --user 0:0 \
  --privileged \
  --cgroupns host \
  --add-host=host.docker.internal:host-gateway \
  --rm \
  -v /sys/fs/cgroup:/sys/fs/cgroup:rw \
  -v /lib/modules:/lib/modules:ro \
  -v clinic-dind-docker:/var/lib/docker \
  -v "$REPO_ROOT:/meta:ro" \
  -v "$CLINIC_DATASET_PATH:/connectors/clinic.csv:ro" \
  -v "$CLINIC_CONNECTOR_PATH:/connectors/us-130-clinics:ro" \
  -e CI_REGISTRY_USER=simon.suewer@uni-hamburg.de \
  -e CI_REGISTRY_PASSWORD=glpat-BEZZaJIPSG8j7uvglydJ6286MQp1OjFsCA.01.0y1tjsn3j \
  -e COMPOSE_PROJECT_NAME="$COMPOSE_PROJECT_NAME" \
  -e DEPLOYED_ON_ADDRESS="$DEPLOYED_ON_ADDRESS" \
  -e DEPLOYED_ON_DOMAIN=localhost \
  -e GLOBAL_BASE_ADDRESS=dev.federated-learning.net \
  -e GLOBAL_LEARNING_API_URL=http://host.docker.internal:8080 \
  -e GLOBAL_LEARNING_API_WEBSOCKET_URL=ws://host.docker.internal:8080 \
  -e GLOBAL_SCHEMA_API_URL=https://dev.federated-learning.net/data-modeler \
  -e GLOBAL_RELAY_HTTP_URL=https://dev.federated-learning.net/relay \
  -e GLOBAL_RELAY_TCP_ADDRESS=dev.federated-learning.net:9150 \
  -p "${HOST_PORT}:80" \
  feddb-dind
