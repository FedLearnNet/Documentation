from pathlib import Path
from typing import Any

from pydantic.dataclasses import dataclass
from pyfedappwrap.learning.run_runfig import AppConfig, AppInputConfig, AppOutputConfig


@dataclass
class HospitalReadmissionConfig(AppConfig):
    target_column: str = "hospital_readmission"
    hidden_dim: int = 64
    n_layers: int = 2
    dropout: float = 0.3
    learning_rate: float = 0.001
    epochs: int = 20
    batch_size: int = 256
    random_state: int = 42
    test_size: float = 0.2


@dataclass
class HospitalReadmissionInputConfig(AppInputConfig):
    data: Any = None


@dataclass
class HospitalReadmissionOutputConfig(AppOutputConfig):
    predictions: Any | None = None
    explanation: Path | None = None
    report: str | None = None


@dataclass
class FederatedHospitalReadmissionConfig(HospitalReadmissionConfig):
    communication_id: str = "hospital-readmission-dl"
    output_filename: str = "federated_dl_readmission_predictions.csv"
    federated_rounds: int = 5
    local_epochs: int = 4
