import os
from pathlib import Path
from typing import Optional

import joblib
import numpy as np
import pandas as pd
from pyfedappwrap.learning.base_app import BaseApp
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from config import (
    HospitalReadmissionConfig,
    HospitalReadmissionInputConfig,
    HospitalReadmissionOutputConfig,
)
from helper import build_prediction_df, generate_explanation_html, preprocess_diabetic


class HospitalReadmissionApp(
    BaseApp[
        HospitalReadmissionConfig,
        HospitalReadmissionInputConfig,
        HospitalReadmissionOutputConfig,
    ]
):
    def __init__(self):
        super().__init__()
        self.model: Optional[SVC] = None
        self.scaler: Optional[StandardScaler] = None
        self.feature_columns: list[str] = []
        self.target_column: str = "hospital_readmission"

    def get_test_data(self) -> Optional[dict[str, Path]]:
        return {"data": Path("data/test_us130_wide.csv")}

    def run_train(self, data: HospitalReadmissionInputConfig) -> HospitalReadmissionOutputConfig:
        self.logger.info("Running train (SVM)")
        cfg: HospitalReadmissionConfig = self.config
        self.target_column = cfg.target_column

        df: pd.DataFrame = data.data
        self.logger.info(f"Dataset loaded: {df.shape[0]} rows x {df.shape[1]} columns")

        X, y, feature_cols = preprocess_diabetic(df, target_col=cfg.target_column, is_training=True)
        self.feature_columns = feature_cols

        X_train, X_val, y_train, y_val = train_test_split(
            X, y, test_size=cfg.test_size, random_state=cfg.random_state, stratify=y,
        )
        self.logger.info(f"Train/val split: {X_train.shape[0]} / {X_val.shape[0]}")

        # SVM requires feature scaling
        self.scaler = StandardScaler()
        X_train = self.scaler.fit_transform(X_train)
        X_val = self.scaler.transform(X_val)
        self.logger.info("Features standardized (required for SVM)")

        class_weight = None if cfg.class_weight == "none" else cfg.class_weight
        self.logger.info(
            f"Fitting SVC(C={cfg.C}, kernel={cfg.kernel}, gamma={cfg.gamma}, "
            f"class_weight={class_weight}, max_iter={cfg.max_iter})"
        )

        # probability=True enables predict_proba via Platt scaling
        self.model = SVC(
            C=cfg.C,
            kernel=cfg.kernel,
            gamma=cfg.gamma,
            class_weight=class_weight,
            max_iter=cfg.max_iter,
            probability=True,
            random_state=cfg.random_state,
        )
        self.model.fit(X_train, y_train)
        self.logger.info("Training complete")

        val_pred = self.model.predict(X_val)
        val_proba = self.model.predict_proba(X_val)[:, 1]
        val_fpr, val_tpr, _ = roc_curve(y_val, val_proba)
        train_pred = self.model.predict(X_train)
        train_proba = self.model.predict_proba(X_train)[:, 1]

        val_accuracy = float(accuracy_score(y_val, val_pred))
        val_auc = float(roc_auc_score(y_val, val_proba))
        val_precision = float(precision_score(y_val, val_pred, zero_division=0))
        val_recall = float(recall_score(y_val, val_pred, zero_division=0))
        val_f1 = float(f1_score(y_val, val_pred, zero_division=0))
        train_accuracy = float(accuracy_score(y_train, train_pred))
        train_auc = float(roc_auc_score(y_train, train_proba))

        self.send_metric("train_accuracy", train_accuracy, 1)
        self.send_metric("val_accuracy", val_accuracy, 1)
        self.send_metric("train_auc", train_auc, 1)
        self.send_metric("val_auc", val_auc, 1)
        self.send_metric("val_precision", val_precision, 1)
        self.send_metric("val_recall", val_recall, 1)
        self.send_metric("val_f1", val_f1, 1)

        metrics = {
            "n_samples_train": int(len(y_train)),
            "n_samples_val": int(len(y_val)),
            "n_features": int(X_train.shape[1]),
            "n_support_vectors": int(self.model.n_support_.sum()),
            "train_accuracy": train_accuracy,
            "val_accuracy": val_accuracy,
            "train_auc": train_auc,
            "val_auc": val_auc,
            "val_precision": val_precision,
            "val_recall": val_recall,
            "val_f1": val_f1,
        }

        self.logger.info(
            f"val_acc={val_accuracy:.4f}  val_auc={val_auc:.4f}  "
            f"precision={val_precision:.4f}  recall={val_recall:.4f}  f1={val_f1:.4f}"
        )

        val_cm = confusion_matrix(y_val, val_pred).tolist()
        val_report = classification_report(y_val, val_pred,
                                           target_names=["Not Readmitted", "Readmitted <30d"])
        self.logger.info(f"Classification Report:\n{val_report}")

        explanation_path = Path("output/explanation.html")
        explanation_path.write_text(
            generate_explanation_html(metrics, val_cm, val_report,
                                      val_fpr=val_fpr, val_tpr=val_tpr),
            encoding="utf-8",
        )

        pred_df = build_prediction_df(list(range(len(y_val))), val_pred, val_proba)
        report = (
            "Hospital Readmission (SVM) — Training Summary\n"
            f"{'=' * 50}\n"
            f"Samples     : {metrics['n_samples_train']} train / {metrics['n_samples_val']} val\n"
            f"Features    : {metrics['n_features']}\n"
            f"Support vecs: {metrics['n_support_vectors']}\n"
            f"\nValidation:\n"
            f"  Accuracy  : {val_accuracy:.4f}\n"
            f"  AUC-ROC   : {val_auc:.4f}\n"
            f"  Precision : {val_precision:.4f}\n"
            f"  Recall    : {val_recall:.4f}\n"
            f"  F1-Score  : {val_f1:.4f}\n"
        )
        self.logger.info(report)
        self._save()

        return HospitalReadmissionOutputConfig(
            predictions=pred_df, explanation=explanation_path, report=report,
        )

    def run_prediction(self, data: HospitalReadmissionInputConfig) -> HospitalReadmissionOutputConfig:
        self._load("model.joblib")
        self.logger.info("Running prediction (SVM)")
        df: pd.DataFrame = data.data

        X, y_true, _ = preprocess_diabetic(
            df, target_col=self.target_column, is_training=False,
            feature_columns=self.feature_columns,
        )
        X = self.scaler.transform(X)

        ids = (df["encounter_identifier"].tolist()
               if "encounter_identifier" in df.columns else list(range(len(df))))

        y_pred = self.model.predict(X)
        y_proba = self.model.predict_proba(X)[:, 1]
        readmit_rate = float(y_pred.mean())
        self.send_metric("predicted_readmission_rate", readmit_rate, 0)

        pred_df = build_prediction_df(ids, y_pred, y_proba)
        metrics = {"n_samples_prediction": len(y_pred), "n_features": X.shape[1],
                   "predicted_readmission_rate": readmit_rate}

        if y_true is not None:
            acc = float(accuracy_score(y_true, y_pred))
            auc = float(roc_auc_score(y_true, y_proba))
            prec = float(precision_score(y_true, y_pred, zero_division=0))
            rec = float(recall_score(y_true, y_pred, zero_division=0))
            f1 = float(f1_score(y_true, y_pred, zero_division=0))
            cm = confusion_matrix(y_true, y_pred).tolist()
            rep_str = classification_report(y_true, y_pred,
                                            target_names=["Not Readmitted", "Readmitted <30d"],
                                            zero_division=0)
            fpr, tpr, _ = roc_curve(y_true, y_proba)
            metrics.update(prediction_accuracy=acc, prediction_auc=auc,
                           prediction_precision=prec, prediction_recall=rec, prediction_f1=f1)
            report = (f"Prediction — {len(y_pred)} samples, rate: {readmit_rate:.1%}\n"
                      f"  Accuracy: {acc:.4f}  AUC: {auc:.4f}  F1: {f1:.4f}\n")
        else:
            cm, rep_str, fpr, tpr = [[0, 0], [0, 0]], "", None, None
            report = f"Prediction — {len(y_pred)} samples, rate: {readmit_rate:.1%}"

        explanation_path = Path("prediction_explanation.html")
        explanation_path.write_text(
            generate_explanation_html(metrics, cm, rep_str, val_fpr=fpr, val_tpr=tpr),
            encoding="utf-8",
        )
        self.logger.info(report)

        return HospitalReadmissionOutputConfig(
            predictions=pred_df, explanation=explanation_path, report=report,
        )

    def _save(self) -> str:
        model_dir = os.environ.get("MODEL_DIR", "./model/")
        path = Path(model_dir) / "model.joblib"
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({"model": self.model, "scaler": self.scaler,
                     "feature_columns": self.feature_columns,
                     "target_column": self.target_column}, path)
        self.logger.info(f"Artifact saved -> {path}")
        return "model.joblib"

    def _load(self, path: str) -> None:
        if self.model is not None:
            return
        model_dir = os.environ.get("MODEL_DIR", "./model/")
        artifact = joblib.load(Path(model_dir) / path)
        self.model = artifact["model"]
        self.scaler = artifact["scaler"]
        self.feature_columns = artifact["feature_columns"]
        self.target_column = artifact["target_column"]
        self.logger.info(f"Artifact loaded <- {path}")
