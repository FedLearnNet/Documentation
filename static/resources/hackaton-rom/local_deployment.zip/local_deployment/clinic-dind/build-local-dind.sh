#!/bin/sh
set -euo pipefail

COMPOSE_FILE="docker-compose.yml"
DOCKERFILE="Dockerfile"
TARFILE="images.tar"
IMAGE_TAG="feddb-dind"

echo "▷ Extracting image names from $COMPOSE_FILE"
images=$(grep '^\s*image:' "$COMPOSE_FILE" \
         | awk '{print $2}' \
         | sort -u)

if [ -z "$images" ]; then
  echo "❌ No images found in $COMPOSE_FILE" >&2
  exit 1
fi

if [ ! -f "$TARFILE" ]; then
  for img in $images; do
    echo "  • Pulling $img"
    docker pull "$img"
  done

  docker save $images -o "$TARFILE"
else
  echo "▷ $TARFILE already exists, skipping image pull and save."
fi
echo "▷ Saved images to $TARFILE"

echo "▷ Building Docker image '$IMAGE_TAG'…"
docker build -t "$IMAGE_TAG"  -f "$DOCKERFILE" .

echo "Delete '$TARFILE' if you want to save space."
rm -f "$TARFILE"
echo "Temporary Dockerfile '$DOCKERFILE' removed."
echo "✅ All done! Built '$IMAGE_TAG' with preloaded images."
