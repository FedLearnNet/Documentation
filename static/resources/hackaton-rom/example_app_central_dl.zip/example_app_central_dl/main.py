from pyfedappwrap.engine.runtime import FedDBEngine
from app import HospitalReadmissionApp

engine = FedDBEngine()
engine.register(HospitalReadmissionApp())

if __name__ == "__main__":
    engine.start()
    engine.wait_until_stop()
