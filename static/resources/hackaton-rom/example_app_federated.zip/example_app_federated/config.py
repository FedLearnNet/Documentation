from pathlib import Path
from typing import Any

from pydantic.dataclasses import dataclass
from pyfedappwrap.learning.run_runfig import AppConfig, AppInputConfig, AppOutputConfig


@dataclass
class HospitalReadmissionConfig(AppConfig):
    target_column: str = "hospital_readmission"
    standardize: bool = True
    C: float = 1.0
    max_iter: int = 1000
    solver: str = "lbfgs"
    class_weight: str = "balanced"
    random_state: int = 42
    test_size: float = 0.2


@dataclass
class HospitalReadmissionInputConfig(AppInputConfig):
    data: Any = None


@dataclass
class HospitalReadmissionOutputConfig(AppOutputConfig):
    predictions: Any | None = None
    coefficients: Any | None = None
    explanation: Path | None = None
    report: str | None = None


@dataclass
class FederatedHospitalReadmissionConfig(HospitalReadmissionConfig):
    communication_id: str = "hospital-readmission"
    output_filename: str = "federated_readmission_predictions.csv"
    federated_rounds: int = 1
    local_max_iter: int = 50
    standardize: bool = False
